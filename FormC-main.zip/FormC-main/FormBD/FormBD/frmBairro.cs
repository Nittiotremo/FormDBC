﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormBD
{
    public partial class frmBairro : Form
    {
        public frmBairro()
        {
            InitializeComponent();
        }

        private void bAIRROBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bAIRROBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fORM2DataSet);

        }

        private void frmBairro_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'fORM2DataSet.BAIRRO'. Você pode movê-la ou removê-la conforme necessário.
            this.bAIRROTableAdapter.Fill(this.fORM2DataSet.BAIRRO);

        }
    }
}
