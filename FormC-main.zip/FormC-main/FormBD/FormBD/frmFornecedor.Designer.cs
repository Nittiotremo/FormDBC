﻿namespace FormBD
{
    partial class frmFornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFornecedor));
            System.Windows.Forms.Label cODFORNECEDORLabel;
            System.Windows.Forms.Label nOMEFORNECEDORLabel;
            System.Windows.Forms.Label nUMEROCASALabel;
            System.Windows.Forms.Label cODCIDADE_FKLabel;
            System.Windows.Forms.Label cODRUA_FKLabel;
            System.Windows.Forms.Label cODBAIRRO_FKLabel;
            System.Windows.Forms.Label cODCEP_FKLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.fORNECEDORBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fORNECEDORTableAdapter = new FormBD.FORM2DataSetTableAdapters.FORNECEDORTableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.fORNECEDORBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.fORNECEDORBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cODFORNECEDORTextBox = new System.Windows.Forms.TextBox();
            this.nOMEFORNECEDORTextBox = new System.Windows.Forms.TextBox();
            this.nUMEROCASATextBox = new System.Windows.Forms.TextBox();
            this.cODCIDADE_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODRUA_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODBAIRRO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODCEP_FKTextBox = new System.Windows.Forms.TextBox();
            this.fORNECEDORDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            cODFORNECEDORLabel = new System.Windows.Forms.Label();
            nOMEFORNECEDORLabel = new System.Windows.Forms.Label();
            nUMEROCASALabel = new System.Windows.Forms.Label();
            cODCIDADE_FKLabel = new System.Windows.Forms.Label();
            cODRUA_FKLabel = new System.Windows.Forms.Label();
            cODBAIRRO_FKLabel = new System.Windows.Forms.Label();
            cODCEP_FKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORBindingNavigator)).BeginInit();
            this.fORNECEDORBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fORNECEDORBindingSource
            // 
            this.fORNECEDORBindingSource.DataMember = "FORNECEDOR";
            this.fORNECEDORBindingSource.DataSource = this.fORM2DataSet;
            // 
            // fORNECEDORTableAdapter
            // 
            this.fORNECEDORTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = this.fORNECEDORTableAdapter;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // fORNECEDORBindingNavigator
            // 
            this.fORNECEDORBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.fORNECEDORBindingNavigator.BindingSource = this.fORNECEDORBindingSource;
            this.fORNECEDORBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.fORNECEDORBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.fORNECEDORBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.fORNECEDORBindingNavigatorSaveItem});
            this.fORNECEDORBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.fORNECEDORBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.fORNECEDORBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.fORNECEDORBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.fORNECEDORBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.fORNECEDORBindingNavigator.Name = "fORNECEDORBindingNavigator";
            this.fORNECEDORBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.fORNECEDORBindingNavigator.Size = new System.Drawing.Size(766, 25);
            this.fORNECEDORBindingNavigator.TabIndex = 0;
            this.fORNECEDORBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // fORNECEDORBindingNavigatorSaveItem
            // 
            this.fORNECEDORBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fORNECEDORBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("fORNECEDORBindingNavigatorSaveItem.Image")));
            this.fORNECEDORBindingNavigatorSaveItem.Name = "fORNECEDORBindingNavigatorSaveItem";
            this.fORNECEDORBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.fORNECEDORBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.fORNECEDORBindingNavigatorSaveItem.Click += new System.EventHandler(this.fORNECEDORBindingNavigatorSaveItem_Click);
            // 
            // cODFORNECEDORLabel
            // 
            cODFORNECEDORLabel.AutoSize = true;
            cODFORNECEDORLabel.Location = new System.Drawing.Point(12, 44);
            cODFORNECEDORLabel.Name = "cODFORNECEDORLabel";
            cODFORNECEDORLabel.Size = new System.Drawing.Size(108, 13);
            cODFORNECEDORLabel.TabIndex = 1;
            cODFORNECEDORLabel.Text = "CODFORNECEDOR:";
            // 
            // cODFORNECEDORTextBox
            // 
            this.cODFORNECEDORTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "CODFORNECEDOR", true));
            this.cODFORNECEDORTextBox.Location = new System.Drawing.Point(135, 41);
            this.cODFORNECEDORTextBox.Name = "cODFORNECEDORTextBox";
            this.cODFORNECEDORTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODFORNECEDORTextBox.TabIndex = 2;
            // 
            // nOMEFORNECEDORLabel
            // 
            nOMEFORNECEDORLabel.AutoSize = true;
            nOMEFORNECEDORLabel.Location = new System.Drawing.Point(12, 70);
            nOMEFORNECEDORLabel.Name = "nOMEFORNECEDORLabel";
            nOMEFORNECEDORLabel.Size = new System.Drawing.Size(117, 13);
            nOMEFORNECEDORLabel.TabIndex = 3;
            nOMEFORNECEDORLabel.Text = "NOMEFORNECEDOR:";
            // 
            // nOMEFORNECEDORTextBox
            // 
            this.nOMEFORNECEDORTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "NOMEFORNECEDOR", true));
            this.nOMEFORNECEDORTextBox.Location = new System.Drawing.Point(135, 67);
            this.nOMEFORNECEDORTextBox.Name = "nOMEFORNECEDORTextBox";
            this.nOMEFORNECEDORTextBox.Size = new System.Drawing.Size(100, 20);
            this.nOMEFORNECEDORTextBox.TabIndex = 4;
            // 
            // nUMEROCASALabel
            // 
            nUMEROCASALabel.AutoSize = true;
            nUMEROCASALabel.Location = new System.Drawing.Point(12, 96);
            nUMEROCASALabel.Name = "nUMEROCASALabel";
            nUMEROCASALabel.Size = new System.Drawing.Size(86, 13);
            nUMEROCASALabel.TabIndex = 5;
            nUMEROCASALabel.Text = "NUMEROCASA:";
            // 
            // nUMEROCASATextBox
            // 
            this.nUMEROCASATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "NUMEROCASA", true));
            this.nUMEROCASATextBox.Location = new System.Drawing.Point(135, 93);
            this.nUMEROCASATextBox.Name = "nUMEROCASATextBox";
            this.nUMEROCASATextBox.Size = new System.Drawing.Size(100, 20);
            this.nUMEROCASATextBox.TabIndex = 6;
            // 
            // cODCIDADE_FKLabel
            // 
            cODCIDADE_FKLabel.AutoSize = true;
            cODCIDADE_FKLabel.Location = new System.Drawing.Point(12, 122);
            cODCIDADE_FKLabel.Name = "cODCIDADE_FKLabel";
            cODCIDADE_FKLabel.Size = new System.Drawing.Size(89, 13);
            cODCIDADE_FKLabel.TabIndex = 7;
            cODCIDADE_FKLabel.Text = "CODCIDADE FK:";
            // 
            // cODCIDADE_FKTextBox
            // 
            this.cODCIDADE_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "CODCIDADE_FK", true));
            this.cODCIDADE_FKTextBox.Location = new System.Drawing.Point(135, 119);
            this.cODCIDADE_FKTextBox.Name = "cODCIDADE_FKTextBox";
            this.cODCIDADE_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODCIDADE_FKTextBox.TabIndex = 8;
            // 
            // cODRUA_FKLabel
            // 
            cODRUA_FKLabel.AutoSize = true;
            cODRUA_FKLabel.Location = new System.Drawing.Point(12, 148);
            cODRUA_FKLabel.Name = "cODRUA_FKLabel";
            cODRUA_FKLabel.Size = new System.Drawing.Size(72, 13);
            cODRUA_FKLabel.TabIndex = 9;
            cODRUA_FKLabel.Text = "CODRUA FK:";
            // 
            // cODRUA_FKTextBox
            // 
            this.cODRUA_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "CODRUA_FK", true));
            this.cODRUA_FKTextBox.Location = new System.Drawing.Point(135, 145);
            this.cODRUA_FKTextBox.Name = "cODRUA_FKTextBox";
            this.cODRUA_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODRUA_FKTextBox.TabIndex = 10;
            // 
            // cODBAIRRO_FKLabel
            // 
            cODBAIRRO_FKLabel.AutoSize = true;
            cODBAIRRO_FKLabel.Location = new System.Drawing.Point(12, 174);
            cODBAIRRO_FKLabel.Name = "cODBAIRRO_FKLabel";
            cODBAIRRO_FKLabel.Size = new System.Drawing.Size(90, 13);
            cODBAIRRO_FKLabel.TabIndex = 11;
            cODBAIRRO_FKLabel.Text = "CODBAIRRO FK:";
            // 
            // cODBAIRRO_FKTextBox
            // 
            this.cODBAIRRO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "CODBAIRRO_FK", true));
            this.cODBAIRRO_FKTextBox.Location = new System.Drawing.Point(135, 171);
            this.cODBAIRRO_FKTextBox.Name = "cODBAIRRO_FKTextBox";
            this.cODBAIRRO_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODBAIRRO_FKTextBox.TabIndex = 12;
            // 
            // cODCEP_FKLabel
            // 
            cODCEP_FKLabel.AutoSize = true;
            cODCEP_FKLabel.Location = new System.Drawing.Point(12, 200);
            cODCEP_FKLabel.Name = "cODCEP_FKLabel";
            cODCEP_FKLabel.Size = new System.Drawing.Size(70, 13);
            cODCEP_FKLabel.TabIndex = 13;
            cODCEP_FKLabel.Text = "CODCEP FK:";
            // 
            // cODCEP_FKTextBox
            // 
            this.cODCEP_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fORNECEDORBindingSource, "CODCEP_FK", true));
            this.cODCEP_FKTextBox.Location = new System.Drawing.Point(135, 197);
            this.cODCEP_FKTextBox.Name = "cODCEP_FKTextBox";
            this.cODCEP_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODCEP_FKTextBox.TabIndex = 14;
            // 
            // fORNECEDORDataGridView
            // 
            this.fORNECEDORDataGridView.AutoGenerateColumns = false;
            this.fORNECEDORDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fORNECEDORDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.fORNECEDORDataGridView.DataSource = this.fORNECEDORBindingSource;
            this.fORNECEDORDataGridView.Location = new System.Drawing.Point(0, 231);
            this.fORNECEDORDataGridView.Name = "fORNECEDORDataGridView";
            this.fORNECEDORDataGridView.Size = new System.Drawing.Size(750, 220);
            this.fORNECEDORDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODFORNECEDOR";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODFORNECEDOR";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMEFORNECEDOR";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMEFORNECEDOR";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NUMEROCASA";
            this.dataGridViewTextBoxColumn3.HeaderText = "NUMEROCASA";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CODRUA_FK";
            this.dataGridViewTextBoxColumn5.HeaderText = "CODRUA_FK";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn6.HeaderText = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CODCEP_FK";
            this.dataGridViewTextBoxColumn7.HeaderText = "CODCEP_FK";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // frmFornecedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 463);
            this.Controls.Add(this.fORNECEDORDataGridView);
            this.Controls.Add(cODFORNECEDORLabel);
            this.Controls.Add(this.cODFORNECEDORTextBox);
            this.Controls.Add(nOMEFORNECEDORLabel);
            this.Controls.Add(this.nOMEFORNECEDORTextBox);
            this.Controls.Add(nUMEROCASALabel);
            this.Controls.Add(this.nUMEROCASATextBox);
            this.Controls.Add(cODCIDADE_FKLabel);
            this.Controls.Add(this.cODCIDADE_FKTextBox);
            this.Controls.Add(cODRUA_FKLabel);
            this.Controls.Add(this.cODRUA_FKTextBox);
            this.Controls.Add(cODBAIRRO_FKLabel);
            this.Controls.Add(this.cODBAIRRO_FKTextBox);
            this.Controls.Add(cODCEP_FKLabel);
            this.Controls.Add(this.cODCEP_FKTextBox);
            this.Controls.Add(this.fORNECEDORBindingNavigator);
            this.Name = "frmFornecedor";
            this.Text = "frmFornecedor";
            this.Load += new System.EventHandler(this.frmFornecedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORBindingNavigator)).EndInit();
            this.fORNECEDORBindingNavigator.ResumeLayout(false);
            this.fORNECEDORBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fORNECEDORDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource fORNECEDORBindingSource;
        private FORM2DataSetTableAdapters.FORNECEDORTableAdapter fORNECEDORTableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator fORNECEDORBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton fORNECEDORBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox cODFORNECEDORTextBox;
        private System.Windows.Forms.TextBox nOMEFORNECEDORTextBox;
        private System.Windows.Forms.TextBox nUMEROCASATextBox;
        private System.Windows.Forms.TextBox cODCIDADE_FKTextBox;
        private System.Windows.Forms.TextBox cODRUA_FKTextBox;
        private System.Windows.Forms.TextBox cODBAIRRO_FKTextBox;
        private System.Windows.Forms.TextBox cODCEP_FKTextBox;
        private System.Windows.Forms.DataGridView fORNECEDORDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}