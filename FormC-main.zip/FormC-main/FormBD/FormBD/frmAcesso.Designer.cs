﻿namespace FormBD
{
    partial class frmAcesso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAcesso));
            System.Windows.Forms.Label cODACESSOLabel;
            System.Windows.Forms.Label nOMEACESSOLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.aCESSOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aCESSOTableAdapter = new FormBD.FORM2DataSetTableAdapters.ACESSOTableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.aCESSOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.aCESSOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.aCESSODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODACESSOTextBox = new System.Windows.Forms.TextBox();
            this.nOMEACESSOTextBox = new System.Windows.Forms.TextBox();
            cODACESSOLabel = new System.Windows.Forms.Label();
            nOMEACESSOLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSOBindingNavigator)).BeginInit();
            this.aCESSOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aCESSOBindingSource
            // 
            this.aCESSOBindingSource.DataMember = "ACESSO";
            this.aCESSOBindingSource.DataSource = this.fORM2DataSet;
            // 
            // aCESSOTableAdapter
            // 
            this.aCESSOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = this.aCESSOTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // aCESSOBindingNavigator
            // 
            this.aCESSOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.aCESSOBindingNavigator.BindingSource = this.aCESSOBindingSource;
            this.aCESSOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.aCESSOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.aCESSOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.aCESSOBindingNavigatorSaveItem});
            this.aCESSOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.aCESSOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.aCESSOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.aCESSOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.aCESSOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.aCESSOBindingNavigator.Name = "aCESSOBindingNavigator";
            this.aCESSOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.aCESSOBindingNavigator.Size = new System.Drawing.Size(336, 25);
            this.aCESSOBindingNavigator.TabIndex = 0;
            this.aCESSOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // aCESSOBindingNavigatorSaveItem
            // 
            this.aCESSOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.aCESSOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("aCESSOBindingNavigatorSaveItem.Image")));
            this.aCESSOBindingNavigatorSaveItem.Name = "aCESSOBindingNavigatorSaveItem";
            this.aCESSOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.aCESSOBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.aCESSOBindingNavigatorSaveItem.Click += new System.EventHandler(this.aCESSOBindingNavigatorSaveItem_Click);
            // 
            // aCESSODataGridView
            // 
            this.aCESSODataGridView.AutoGenerateColumns = false;
            this.aCESSODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aCESSODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.aCESSODataGridView.DataSource = this.aCESSOBindingSource;
            this.aCESSODataGridView.Location = new System.Drawing.Point(12, 156);
            this.aCESSODataGridView.Name = "aCESSODataGridView";
            this.aCESSODataGridView.Size = new System.Drawing.Size(300, 220);
            this.aCESSODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODACESSO";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODACESSO";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMEACESSO";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMEACESSO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // cODACESSOLabel
            // 
            cODACESSOLabel.AutoSize = true;
            cODACESSOLabel.Location = new System.Drawing.Point(12, 53);
            cODACESSOLabel.Name = "cODACESSOLabel";
            cODACESSOLabel.Size = new System.Drawing.Size(76, 13);
            cODACESSOLabel.TabIndex = 2;
            cODACESSOLabel.Text = "CODACESSO:";
            // 
            // cODACESSOTextBox
            // 
            this.cODACESSOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aCESSOBindingSource, "CODACESSO", true));
            this.cODACESSOTextBox.Location = new System.Drawing.Point(103, 50);
            this.cODACESSOTextBox.Name = "cODACESSOTextBox";
            this.cODACESSOTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODACESSOTextBox.TabIndex = 3;
            // 
            // nOMEACESSOLabel
            // 
            nOMEACESSOLabel.AutoSize = true;
            nOMEACESSOLabel.Location = new System.Drawing.Point(12, 79);
            nOMEACESSOLabel.Name = "nOMEACESSOLabel";
            nOMEACESSOLabel.Size = new System.Drawing.Size(85, 13);
            nOMEACESSOLabel.TabIndex = 4;
            nOMEACESSOLabel.Text = "NOMEACESSO:";
            // 
            // nOMEACESSOTextBox
            // 
            this.nOMEACESSOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aCESSOBindingSource, "NOMEACESSO", true));
            this.nOMEACESSOTextBox.Location = new System.Drawing.Point(103, 76);
            this.nOMEACESSOTextBox.Name = "nOMEACESSOTextBox";
            this.nOMEACESSOTextBox.Size = new System.Drawing.Size(100, 20);
            this.nOMEACESSOTextBox.TabIndex = 5;
            // 
            // frmAcesso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 399);
            this.Controls.Add(cODACESSOLabel);
            this.Controls.Add(this.cODACESSOTextBox);
            this.Controls.Add(nOMEACESSOLabel);
            this.Controls.Add(this.nOMEACESSOTextBox);
            this.Controls.Add(this.aCESSODataGridView);
            this.Controls.Add(this.aCESSOBindingNavigator);
            this.Name = "frmAcesso";
            this.Text = "frmAcesso";
            this.Load += new System.EventHandler(this.frmAcesso_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSOBindingNavigator)).EndInit();
            this.aCESSOBindingNavigator.ResumeLayout(false);
            this.aCESSOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCESSODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource aCESSOBindingSource;
        private FORM2DataSetTableAdapters.ACESSOTableAdapter aCESSOTableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator aCESSOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton aCESSOBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView aCESSODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox cODACESSOTextBox;
        private System.Windows.Forms.TextBox nOMEACESSOTextBox;
    }
}