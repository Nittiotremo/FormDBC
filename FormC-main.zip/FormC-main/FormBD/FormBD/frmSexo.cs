﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormBD
{
    public partial class frmSexo : Form
    {
        public frmSexo()
        {
            InitializeComponent();
        }

        private void sEXOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sEXOBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fORM2DataSet);

        }

        private void frmSexo_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'fORM2DataSet.SEXO'. Você pode movê-la ou removê-la conforme necessário.
            this.sEXOTableAdapter.Fill(this.fORM2DataSet.SEXO);

        }
    }
}
