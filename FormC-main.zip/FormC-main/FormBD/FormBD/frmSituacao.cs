﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormBD
{
    public partial class frmSituacao : Form
    {
        public frmSituacao()
        {
            InitializeComponent();
        }

        private void sITUACAOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sITUACAOBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fORM2DataSet);

        }

        private void frmSituacao_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'fORM2DataSet.SITUACAO'. Você pode movê-la ou removê-la conforme necessário.
            this.sITUACAOTableAdapter.Fill(this.fORM2DataSet.SITUACAO);

        }
    }
}
