﻿namespace FormBD
{
    partial class frmCompraProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompraProduto));
            System.Windows.Forms.Label cODCOMPRALabel;
            System.Windows.Forms.Label dATACOMPRALabel;
            System.Windows.Forms.Label cODTELEFONE_FKLabel;
            System.Windows.Forms.Label cODFORNECEDOR_FKLabel;
            System.Windows.Forms.Label cODFUNCIONARIO_FKLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.cOMPRAPRODUTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cOMPRAPRODUTOTableAdapter = new FormBD.FORM2DataSetTableAdapters.COMPRAPRODUTOTableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.cOMPRAPRODUTOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.cOMPRAPRODUTOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cOMPRAPRODUTODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODCOMPRATextBox = new System.Windows.Forms.TextBox();
            this.dATACOMPRADateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cODTELEFONE_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODFORNECEDOR_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODFUNCIONARIO_FKTextBox = new System.Windows.Forms.TextBox();
            cODCOMPRALabel = new System.Windows.Forms.Label();
            dATACOMPRALabel = new System.Windows.Forms.Label();
            cODTELEFONE_FKLabel = new System.Windows.Forms.Label();
            cODFORNECEDOR_FKLabel = new System.Windows.Forms.Label();
            cODFUNCIONARIO_FKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTOBindingNavigator)).BeginInit();
            this.cOMPRAPRODUTOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cOMPRAPRODUTOBindingSource
            // 
            this.cOMPRAPRODUTOBindingSource.DataMember = "COMPRAPRODUTO";
            this.cOMPRAPRODUTOBindingSource.DataSource = this.fORM2DataSet;
            // 
            // cOMPRAPRODUTOTableAdapter
            // 
            this.cOMPRAPRODUTOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = this.cOMPRAPRODUTOTableAdapter;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // cOMPRAPRODUTOBindingNavigator
            // 
            this.cOMPRAPRODUTOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cOMPRAPRODUTOBindingNavigator.BindingSource = this.cOMPRAPRODUTOBindingSource;
            this.cOMPRAPRODUTOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cOMPRAPRODUTOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cOMPRAPRODUTOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cOMPRAPRODUTOBindingNavigatorSaveItem});
            this.cOMPRAPRODUTOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cOMPRAPRODUTOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cOMPRAPRODUTOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cOMPRAPRODUTOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cOMPRAPRODUTOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cOMPRAPRODUTOBindingNavigator.Name = "cOMPRAPRODUTOBindingNavigator";
            this.cOMPRAPRODUTOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cOMPRAPRODUTOBindingNavigator.Size = new System.Drawing.Size(577, 25);
            this.cOMPRAPRODUTOBindingNavigator.TabIndex = 0;
            this.cOMPRAPRODUTOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // cOMPRAPRODUTOBindingNavigatorSaveItem
            // 
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cOMPRAPRODUTOBindingNavigatorSaveItem.Image")));
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.Name = "cOMPRAPRODUTOBindingNavigatorSaveItem";
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.cOMPRAPRODUTOBindingNavigatorSaveItem.Click += new System.EventHandler(this.cOMPRAPRODUTOBindingNavigatorSaveItem_Click);
            // 
            // cOMPRAPRODUTODataGridView
            // 
            this.cOMPRAPRODUTODataGridView.AutoGenerateColumns = false;
            this.cOMPRAPRODUTODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cOMPRAPRODUTODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.cOMPRAPRODUTODataGridView.DataSource = this.cOMPRAPRODUTOBindingSource;
            this.cOMPRAPRODUTODataGridView.Location = new System.Drawing.Point(0, 184);
            this.cOMPRAPRODUTODataGridView.Name = "cOMPRAPRODUTODataGridView";
            this.cOMPRAPRODUTODataGridView.Size = new System.Drawing.Size(556, 220);
            this.cOMPRAPRODUTODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODCOMPRA";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODCOMPRA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DATACOMPRA";
            this.dataGridViewTextBoxColumn2.HeaderText = "DATACOMPRA";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "CODTELEFONE_FK";
            this.dataGridViewTextBoxColumn3.HeaderText = "CODTELEFONE_FK";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODFORNECEDOR_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODFORNECEDOR_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn5.HeaderText = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // cODCOMPRALabel
            // 
            cODCOMPRALabel.AutoSize = true;
            cODCOMPRALabel.Location = new System.Drawing.Point(12, 48);
            cODCOMPRALabel.Name = "cODCOMPRALabel";
            cODCOMPRALabel.Size = new System.Drawing.Size(79, 13);
            cODCOMPRALabel.TabIndex = 2;
            cODCOMPRALabel.Text = "CODCOMPRA:";
            // 
            // cODCOMPRATextBox
            // 
            this.cODCOMPRATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOMPRAPRODUTOBindingSource, "CODCOMPRA", true));
            this.cODCOMPRATextBox.Location = new System.Drawing.Point(142, 45);
            this.cODCOMPRATextBox.Name = "cODCOMPRATextBox";
            this.cODCOMPRATextBox.Size = new System.Drawing.Size(200, 20);
            this.cODCOMPRATextBox.TabIndex = 3;
            // 
            // dATACOMPRALabel
            // 
            dATACOMPRALabel.AutoSize = true;
            dATACOMPRALabel.Location = new System.Drawing.Point(12, 75);
            dATACOMPRALabel.Name = "dATACOMPRALabel";
            dATACOMPRALabel.Size = new System.Drawing.Size(85, 13);
            dATACOMPRALabel.TabIndex = 4;
            dATACOMPRALabel.Text = "DATACOMPRA:";
            // 
            // dATACOMPRADateTimePicker
            // 
            this.dATACOMPRADateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.cOMPRAPRODUTOBindingSource, "DATACOMPRA", true));
            this.dATACOMPRADateTimePicker.Location = new System.Drawing.Point(142, 71);
            this.dATACOMPRADateTimePicker.Name = "dATACOMPRADateTimePicker";
            this.dATACOMPRADateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dATACOMPRADateTimePicker.TabIndex = 5;
            // 
            // cODTELEFONE_FKLabel
            // 
            cODTELEFONE_FKLabel.AutoSize = true;
            cODTELEFONE_FKLabel.Location = new System.Drawing.Point(12, 100);
            cODTELEFONE_FKLabel.Name = "cODTELEFONE_FKLabel";
            cODTELEFONE_FKLabel.Size = new System.Drawing.Size(105, 13);
            cODTELEFONE_FKLabel.TabIndex = 6;
            cODTELEFONE_FKLabel.Text = "CODTELEFONE FK:";
            // 
            // cODTELEFONE_FKTextBox
            // 
            this.cODTELEFONE_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOMPRAPRODUTOBindingSource, "CODTELEFONE_FK", true));
            this.cODTELEFONE_FKTextBox.Location = new System.Drawing.Point(142, 97);
            this.cODTELEFONE_FKTextBox.Name = "cODTELEFONE_FKTextBox";
            this.cODTELEFONE_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODTELEFONE_FKTextBox.TabIndex = 7;
            // 
            // cODFORNECEDOR_FKLabel
            // 
            cODFORNECEDOR_FKLabel.AutoSize = true;
            cODFORNECEDOR_FKLabel.Location = new System.Drawing.Point(12, 126);
            cODFORNECEDOR_FKLabel.Name = "cODFORNECEDOR_FKLabel";
            cODFORNECEDOR_FKLabel.Size = new System.Drawing.Size(124, 13);
            cODFORNECEDOR_FKLabel.TabIndex = 8;
            cODFORNECEDOR_FKLabel.Text = "CODFORNECEDOR FK:";
            // 
            // cODFORNECEDOR_FKTextBox
            // 
            this.cODFORNECEDOR_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOMPRAPRODUTOBindingSource, "CODFORNECEDOR_FK", true));
            this.cODFORNECEDOR_FKTextBox.Location = new System.Drawing.Point(142, 123);
            this.cODFORNECEDOR_FKTextBox.Name = "cODFORNECEDOR_FKTextBox";
            this.cODFORNECEDOR_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODFORNECEDOR_FKTextBox.TabIndex = 9;
            // 
            // cODFUNCIONARIO_FKLabel
            // 
            cODFUNCIONARIO_FKLabel.AutoSize = true;
            cODFUNCIONARIO_FKLabel.Location = new System.Drawing.Point(12, 152);
            cODFUNCIONARIO_FKLabel.Name = "cODFUNCIONARIO_FKLabel";
            cODFUNCIONARIO_FKLabel.Size = new System.Drawing.Size(123, 13);
            cODFUNCIONARIO_FKLabel.TabIndex = 10;
            cODFUNCIONARIO_FKLabel.Text = "CODFUNCIONARIO FK:";
            // 
            // cODFUNCIONARIO_FKTextBox
            // 
            this.cODFUNCIONARIO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOMPRAPRODUTOBindingSource, "CODFUNCIONARIO_FK", true));
            this.cODFUNCIONARIO_FKTextBox.Location = new System.Drawing.Point(142, 149);
            this.cODFUNCIONARIO_FKTextBox.Name = "cODFUNCIONARIO_FKTextBox";
            this.cODFUNCIONARIO_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODFUNCIONARIO_FKTextBox.TabIndex = 11;
            // 
            // frmCompraProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 416);
            this.Controls.Add(cODCOMPRALabel);
            this.Controls.Add(this.cODCOMPRATextBox);
            this.Controls.Add(dATACOMPRALabel);
            this.Controls.Add(this.dATACOMPRADateTimePicker);
            this.Controls.Add(cODTELEFONE_FKLabel);
            this.Controls.Add(this.cODTELEFONE_FKTextBox);
            this.Controls.Add(cODFORNECEDOR_FKLabel);
            this.Controls.Add(this.cODFORNECEDOR_FKTextBox);
            this.Controls.Add(cODFUNCIONARIO_FKLabel);
            this.Controls.Add(this.cODFUNCIONARIO_FKTextBox);
            this.Controls.Add(this.cOMPRAPRODUTODataGridView);
            this.Controls.Add(this.cOMPRAPRODUTOBindingNavigator);
            this.Name = "frmCompraProduto";
            this.Text = "frmCompraProduto";
            this.Load += new System.EventHandler(this.frmCompraProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTOBindingNavigator)).EndInit();
            this.cOMPRAPRODUTOBindingNavigator.ResumeLayout(false);
            this.cOMPRAPRODUTOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cOMPRAPRODUTODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource cOMPRAPRODUTOBindingSource;
        private FORM2DataSetTableAdapters.COMPRAPRODUTOTableAdapter cOMPRAPRODUTOTableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cOMPRAPRODUTOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cOMPRAPRODUTOBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView cOMPRAPRODUTODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TextBox cODCOMPRATextBox;
        private System.Windows.Forms.DateTimePicker dATACOMPRADateTimePicker;
        private System.Windows.Forms.TextBox cODTELEFONE_FKTextBox;
        private System.Windows.Forms.TextBox cODFORNECEDOR_FKTextBox;
        private System.Windows.Forms.TextBox cODFUNCIONARIO_FKTextBox;
    }
}