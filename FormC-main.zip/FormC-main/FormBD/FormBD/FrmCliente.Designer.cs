﻿namespace FormBD
{
    partial class FrmCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nOMECLIENTELabel;
            System.Windows.Forms.Label cODSEXO_FKLabel;
            System.Windows.Forms.Label cODRUA_FKLabel;
            System.Windows.Forms.Label cODBAIRRO_FKLabel;
            System.Windows.Forms.Label cODCEP_FKLabel;
            System.Windows.Forms.Label cODCIDADE_FKLabel;
            System.Windows.Forms.Label sALARIOCLIENTELabel;
            System.Windows.Forms.Label cODTRABALHO_FKLabel;
            System.Windows.Forms.Label nUMEROCASALabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCliente));
            System.Windows.Forms.Label dATANASCLabel1;
            System.Windows.Forms.Label cODCLIENTELabel;
            this.formBdDataSet = new FormBD.formBdDataSet();
            this.cLIENTEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cLIENTETableAdapter = new FormBD.formBdDataSetTableAdapters.CLIENTETableAdapter();
            this.tableAdapterManager = new FormBD.formBdDataSetTableAdapters.TableAdapterManager();
            this.cLIENTEBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cLIENTEBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cLIENTEDataGridView = new System.Windows.Forms.DataGridView();
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.cLIENTEBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cLIENTETableAdapter1 = new FormBD.FORM2DataSetTableAdapters.CLIENTETableAdapter();
            this.tableAdapterManager1 = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.nOMECLIENTETextBox = new System.Windows.Forms.TextBox();
            this.cODSEXO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODRUA_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODBAIRRO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODCEP_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODCIDADE_FKTextBox = new System.Windows.Forms.TextBox();
            this.sALARIOCLIENTETextBox = new System.Windows.Forms.TextBox();
            this.cODTRABALHO_FKTextBox = new System.Windows.Forms.TextBox();
            this.nUMEROCASATextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATANASCDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cODCLIENTETextBox = new System.Windows.Forms.TextBox();
            nOMECLIENTELabel = new System.Windows.Forms.Label();
            cODSEXO_FKLabel = new System.Windows.Forms.Label();
            cODRUA_FKLabel = new System.Windows.Forms.Label();
            cODBAIRRO_FKLabel = new System.Windows.Forms.Label();
            cODCEP_FKLabel = new System.Windows.Forms.Label();
            cODCIDADE_FKLabel = new System.Windows.Forms.Label();
            sALARIOCLIENTELabel = new System.Windows.Forms.Label();
            cODTRABALHO_FKLabel = new System.Windows.Forms.Label();
            nUMEROCASALabel = new System.Windows.Forms.Label();
            dATANASCLabel1 = new System.Windows.Forms.Label();
            cODCLIENTELabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.formBdDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingNavigator)).BeginInit();
            this.cLIENTEBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // nOMECLIENTELabel
            // 
            nOMECLIENTELabel.AutoSize = true;
            nOMECLIENTELabel.Location = new System.Drawing.Point(12, 69);
            nOMECLIENTELabel.Name = "nOMECLIENTELabel";
            nOMECLIENTELabel.Size = new System.Drawing.Size(87, 13);
            nOMECLIENTELabel.TabIndex = 4;
            nOMECLIENTELabel.Text = "NOMECLIENTE:";
            // 
            // cODSEXO_FKLabel
            // 
            cODSEXO_FKLabel.AutoSize = true;
            cODSEXO_FKLabel.Location = new System.Drawing.Point(12, 121);
            cODSEXO_FKLabel.Name = "cODSEXO_FKLabel";
            cODSEXO_FKLabel.Size = new System.Drawing.Size(78, 13);
            cODSEXO_FKLabel.TabIndex = 8;
            cODSEXO_FKLabel.Text = "CODSEXO FK:";
            // 
            // cODRUA_FKLabel
            // 
            cODRUA_FKLabel.AutoSize = true;
            cODRUA_FKLabel.Location = new System.Drawing.Point(12, 147);
            cODRUA_FKLabel.Name = "cODRUA_FKLabel";
            cODRUA_FKLabel.Size = new System.Drawing.Size(72, 13);
            cODRUA_FKLabel.TabIndex = 10;
            cODRUA_FKLabel.Text = "CODRUA FK:";
            // 
            // cODBAIRRO_FKLabel
            // 
            cODBAIRRO_FKLabel.AutoSize = true;
            cODBAIRRO_FKLabel.Location = new System.Drawing.Point(248, 43);
            cODBAIRRO_FKLabel.Name = "cODBAIRRO_FKLabel";
            cODBAIRRO_FKLabel.Size = new System.Drawing.Size(90, 13);
            cODBAIRRO_FKLabel.TabIndex = 12;
            cODBAIRRO_FKLabel.Text = "CODBAIRRO FK:";
            // 
            // cODCEP_FKLabel
            // 
            cODCEP_FKLabel.AutoSize = true;
            cODCEP_FKLabel.Location = new System.Drawing.Point(248, 69);
            cODCEP_FKLabel.Name = "cODCEP_FKLabel";
            cODCEP_FKLabel.Size = new System.Drawing.Size(70, 13);
            cODCEP_FKLabel.TabIndex = 14;
            cODCEP_FKLabel.Text = "CODCEP FK:";
            // 
            // cODCIDADE_FKLabel
            // 
            cODCIDADE_FKLabel.AutoSize = true;
            cODCIDADE_FKLabel.Location = new System.Drawing.Point(248, 95);
            cODCIDADE_FKLabel.Name = "cODCIDADE_FKLabel";
            cODCIDADE_FKLabel.Size = new System.Drawing.Size(89, 13);
            cODCIDADE_FKLabel.TabIndex = 16;
            cODCIDADE_FKLabel.Text = "CODCIDADE FK:";
            // 
            // sALARIOCLIENTELabel
            // 
            sALARIOCLIENTELabel.AutoSize = true;
            sALARIOCLIENTELabel.Location = new System.Drawing.Point(248, 121);
            sALARIOCLIENTELabel.Name = "sALARIOCLIENTELabel";
            sALARIOCLIENTELabel.Size = new System.Drawing.Size(101, 13);
            sALARIOCLIENTELabel.TabIndex = 18;
            sALARIOCLIENTELabel.Text = "SALARIOCLIENTE:";
            // 
            // cODTRABALHO_FKLabel
            // 
            cODTRABALHO_FKLabel.AutoSize = true;
            cODTRABALHO_FKLabel.Location = new System.Drawing.Point(248, 154);
            cODTRABALHO_FKLabel.Name = "cODTRABALHO_FKLabel";
            cODTRABALHO_FKLabel.Size = new System.Drawing.Size(107, 13);
            cODTRABALHO_FKLabel.TabIndex = 20;
            cODTRABALHO_FKLabel.Text = "CODTRABALHO FK:";
            // 
            // nUMEROCASALabel
            // 
            nUMEROCASALabel.AutoSize = true;
            nUMEROCASALabel.Location = new System.Drawing.Point(248, 183);
            nUMEROCASALabel.Name = "nUMEROCASALabel";
            nUMEROCASALabel.Size = new System.Drawing.Size(86, 13);
            nUMEROCASALabel.TabIndex = 22;
            nUMEROCASALabel.Text = "NUMEROCASA:";
            // 
            // formBdDataSet
            // 
            this.formBdDataSet.DataSetName = "formBdDataSet";
            this.formBdDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cLIENTEBindingSource
            // 
            this.cLIENTEBindingSource.DataMember = "CLIENTE";
            this.cLIENTEBindingSource.DataSource = this.formBdDataSet;
            // 
            // cLIENTETableAdapter
            // 
            this.cLIENTETableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = this.cLIENTETableAdapter;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.formBdDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // cLIENTEBindingNavigator
            // 
            this.cLIENTEBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cLIENTEBindingNavigator.BindingSource = this.cLIENTEBindingSource;
            this.cLIENTEBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cLIENTEBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cLIENTEBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cLIENTEBindingNavigatorSaveItem});
            this.cLIENTEBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cLIENTEBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cLIENTEBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cLIENTEBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cLIENTEBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cLIENTEBindingNavigator.Name = "cLIENTEBindingNavigator";
            this.cLIENTEBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cLIENTEBindingNavigator.Size = new System.Drawing.Size(900, 25);
            this.cLIENTEBindingNavigator.TabIndex = 0;
            this.cLIENTEBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // cLIENTEBindingNavigatorSaveItem
            // 
            this.cLIENTEBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cLIENTEBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cLIENTEBindingNavigatorSaveItem.Image")));
            this.cLIENTEBindingNavigatorSaveItem.Name = "cLIENTEBindingNavigatorSaveItem";
            this.cLIENTEBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.cLIENTEBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.cLIENTEBindingNavigatorSaveItem.Click += new System.EventHandler(this.cLIENTEBindingNavigatorSaveItem_Click);
            // 
            // cLIENTEDataGridView
            // 
            this.cLIENTEDataGridView.AutoGenerateColumns = false;
            this.cLIENTEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cLIENTEDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.cLIENTEDataGridView.DataSource = this.cLIENTEBindingSource;
            this.cLIENTEDataGridView.Location = new System.Drawing.Point(-1, 250);
            this.cLIENTEDataGridView.Name = "cLIENTEDataGridView";
            this.cLIENTEDataGridView.ReadOnly = true;
            this.cLIENTEDataGridView.Size = new System.Drawing.Size(881, 220);
            this.cLIENTEDataGridView.TabIndex = 1;
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cLIENTEBindingSource1
            // 
            this.cLIENTEBindingSource1.DataMember = "CLIENTE";
            this.cLIENTEBindingSource1.DataSource = this.fORM2DataSet;
            // 
            // cLIENTETableAdapter1
            // 
            this.cLIENTETableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.ACESSOTableAdapter = null;
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.BAIRROTableAdapter = null;
            this.tableAdapterManager1.CEPTableAdapter = null;
            this.tableAdapterManager1.CIDADETableAdapter = null;
            this.tableAdapterManager1.CLIENTETableAdapter = this.cLIENTETableAdapter1;
            this.tableAdapterManager1.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager1.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager1.FORNECEDORTableAdapter = null;
            this.tableAdapterManager1.FUNCAOTableAdapter = null;
            this.tableAdapterManager1.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager1.IMAGENSTableAdapter = null;
            this.tableAdapterManager1.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager1.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager1.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager1.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager1.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager1.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager1.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager1.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager1.LOGINTableAdapter = null;
            this.tableAdapterManager1.LOJATableAdapter = null;
            this.tableAdapterManager1.MARCATableAdapter = null;
            this.tableAdapterManager1.OPERADORATableAdapter = null;
            this.tableAdapterManager1.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager1.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager1.PRODUTOTableAdapter = null;
            this.tableAdapterManager1.RUATableAdapter = null;
            this.tableAdapterManager1.SEXOTableAdapter = null;
            this.tableAdapterManager1.SITUACAOTableAdapter = null;
            this.tableAdapterManager1.TELEFONETableAdapter = null;
            this.tableAdapterManager1.TIPOTableAdapter = null;
            this.tableAdapterManager1.TRABALHOTableAdapter = null;
            this.tableAdapterManager1.UFTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.VENDAPRODUTOTableAdapter = null;
            // 
            // nOMECLIENTETextBox
            // 
            this.nOMECLIENTETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "NOMECLIENTE", true));
            this.nOMECLIENTETextBox.Location = new System.Drawing.Point(125, 66);
            this.nOMECLIENTETextBox.Name = "nOMECLIENTETextBox";
            this.nOMECLIENTETextBox.Size = new System.Drawing.Size(100, 20);
            this.nOMECLIENTETextBox.TabIndex = 5;
            // 
            // cODSEXO_FKTextBox
            // 
            this.cODSEXO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODSEXO_FK", true));
            this.cODSEXO_FKTextBox.Location = new System.Drawing.Point(125, 118);
            this.cODSEXO_FKTextBox.Name = "cODSEXO_FKTextBox";
            this.cODSEXO_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODSEXO_FKTextBox.TabIndex = 9;
            // 
            // cODRUA_FKTextBox
            // 
            this.cODRUA_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODRUA_FK", true));
            this.cODRUA_FKTextBox.Location = new System.Drawing.Point(125, 144);
            this.cODRUA_FKTextBox.Name = "cODRUA_FKTextBox";
            this.cODRUA_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODRUA_FKTextBox.TabIndex = 11;
            // 
            // cODBAIRRO_FKTextBox
            // 
            this.cODBAIRRO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODBAIRRO_FK", true));
            this.cODBAIRRO_FKTextBox.Location = new System.Drawing.Point(360, 43);
            this.cODBAIRRO_FKTextBox.Name = "cODBAIRRO_FKTextBox";
            this.cODBAIRRO_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODBAIRRO_FKTextBox.TabIndex = 13;
            // 
            // cODCEP_FKTextBox
            // 
            this.cODCEP_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODCEP_FK", true));
            this.cODCEP_FKTextBox.Location = new System.Drawing.Point(360, 69);
            this.cODCEP_FKTextBox.Name = "cODCEP_FKTextBox";
            this.cODCEP_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODCEP_FKTextBox.TabIndex = 15;
            // 
            // cODCIDADE_FKTextBox
            // 
            this.cODCIDADE_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODCIDADE_FK", true));
            this.cODCIDADE_FKTextBox.Location = new System.Drawing.Point(360, 95);
            this.cODCIDADE_FKTextBox.Name = "cODCIDADE_FKTextBox";
            this.cODCIDADE_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODCIDADE_FKTextBox.TabIndex = 17;
            // 
            // sALARIOCLIENTETextBox
            // 
            this.sALARIOCLIENTETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "SALARIOCLIENTE", true));
            this.sALARIOCLIENTETextBox.Location = new System.Drawing.Point(360, 121);
            this.sALARIOCLIENTETextBox.Name = "sALARIOCLIENTETextBox";
            this.sALARIOCLIENTETextBox.Size = new System.Drawing.Size(100, 20);
            this.sALARIOCLIENTETextBox.TabIndex = 19;
            // 
            // cODTRABALHO_FKTextBox
            // 
            this.cODTRABALHO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODTRABALHO_FK", true));
            this.cODTRABALHO_FKTextBox.Location = new System.Drawing.Point(360, 147);
            this.cODTRABALHO_FKTextBox.Name = "cODTRABALHO_FKTextBox";
            this.cODTRABALHO_FKTextBox.Size = new System.Drawing.Size(100, 20);
            this.cODTRABALHO_FKTextBox.TabIndex = 21;
            // 
            // nUMEROCASATextBox
            // 
            this.nUMEROCASATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "NUMEROCASA", true));
            this.nUMEROCASATextBox.Location = new System.Drawing.Point(360, 176);
            this.nUMEROCASATextBox.Name = "nUMEROCASATextBox";
            this.nUMEROCASATextBox.Size = new System.Drawing.Size(100, 20);
            this.nUMEROCASATextBox.TabIndex = 23;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODCLIENTE";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODCLIENTE";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMECLIENTE";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMECLIENTE";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DATANASC";
            this.dataGridViewTextBoxColumn3.HeaderText = "DATANASC";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODSEXO_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODSEXO_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CODRUA_FK";
            this.dataGridViewTextBoxColumn5.HeaderText = "CODRUA_FK";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn6.HeaderText = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CODCEP_FK";
            this.dataGridViewTextBoxColumn7.HeaderText = "CODCEP_FK";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn8.HeaderText = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "SALARIOCLIENTE";
            this.dataGridViewTextBoxColumn9.HeaderText = "SALARIOCLIENTE";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CODTRABALHO_FK";
            this.dataGridViewTextBoxColumn10.HeaderText = "CODTRABALHO_FK";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "NUMEROCASA";
            this.dataGridViewTextBoxColumn11.HeaderText = "NUMEROCASA";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dATANASCLabel1
            // 
            dATANASCLabel1.AutoSize = true;
            dATANASCLabel1.Location = new System.Drawing.Point(12, 95);
            dATANASCLabel1.Name = "dATANASCLabel1";
            dATANASCLabel1.Size = new System.Drawing.Size(68, 13);
            dATANASCLabel1.TabIndex = 23;
            dATANASCLabel1.Text = "DATANASC:";
            // 
            // dATANASCDateTimePicker
            // 
            this.dATANASCDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.cLIENTEBindingSource1, "DATANASC", true));
            this.dATANASCDateTimePicker.Location = new System.Drawing.Point(125, 92);
            this.dATANASCDateTimePicker.Name = "dATANASCDateTimePicker";
            this.dATANASCDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.dATANASCDateTimePicker.TabIndex = 24;
            this.dATANASCDateTimePicker.TabStop = false;
            this.dATANASCDateTimePicker.Value = new System.DateTime(2023, 5, 30, 16, 41, 35, 0);
            // 
            // cODCLIENTELabel
            // 
            cODCLIENTELabel.AutoSize = true;
            cODCLIENTELabel.Location = new System.Drawing.Point(12, 43);
            cODCLIENTELabel.Name = "cODCLIENTELabel";
            cODCLIENTELabel.Size = new System.Drawing.Size(78, 13);
            cODCLIENTELabel.TabIndex = 24;
            cODCLIENTELabel.Text = "CODCLIENTE:";
            // 
            // cODCLIENTETextBox
            // 
            this.cODCLIENTETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cLIENTEBindingSource1, "CODCLIENTE", true));
            this.cODCLIENTETextBox.Location = new System.Drawing.Point(125, 40);
            this.cODCLIENTETextBox.Name = "cODCLIENTETextBox";
            this.cODCLIENTETextBox.Size = new System.Drawing.Size(100, 20);
            this.cODCLIENTETextBox.TabIndex = 25;
            // 
            // FrmCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 490);
            this.Controls.Add(cODCLIENTELabel);
            this.Controls.Add(this.cODCLIENTETextBox);
            this.Controls.Add(dATANASCLabel1);
            this.Controls.Add(this.dATANASCDateTimePicker);
            this.Controls.Add(nOMECLIENTELabel);
            this.Controls.Add(this.nOMECLIENTETextBox);
            this.Controls.Add(cODSEXO_FKLabel);
            this.Controls.Add(this.cODSEXO_FKTextBox);
            this.Controls.Add(cODRUA_FKLabel);
            this.Controls.Add(this.cODRUA_FKTextBox);
            this.Controls.Add(cODBAIRRO_FKLabel);
            this.Controls.Add(this.cODBAIRRO_FKTextBox);
            this.Controls.Add(cODCEP_FKLabel);
            this.Controls.Add(this.cODCEP_FKTextBox);
            this.Controls.Add(cODCIDADE_FKLabel);
            this.Controls.Add(this.cODCIDADE_FKTextBox);
            this.Controls.Add(sALARIOCLIENTELabel);
            this.Controls.Add(this.sALARIOCLIENTETextBox);
            this.Controls.Add(cODTRABALHO_FKLabel);
            this.Controls.Add(this.cODTRABALHO_FKTextBox);
            this.Controls.Add(nUMEROCASALabel);
            this.Controls.Add(this.nUMEROCASATextBox);
            this.Controls.Add(this.cLIENTEDataGridView);
            this.Controls.Add(this.cLIENTEBindingNavigator);
            this.Name = "FrmCliente";
            this.Text = "FrmCliente";
            this.Load += new System.EventHandler(this.FrmCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.formBdDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingNavigator)).EndInit();
            this.cLIENTEBindingNavigator.ResumeLayout(false);
            this.cLIENTEBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cLIENTEBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private formBdDataSet formBdDataSet;
        private System.Windows.Forms.BindingSource cLIENTEBindingSource;
        private formBdDataSetTableAdapters.CLIENTETableAdapter cLIENTETableAdapter;
        private formBdDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cLIENTEBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cLIENTEBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView cLIENTEDataGridView;
        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource cLIENTEBindingSource1;
        private FORM2DataSetTableAdapters.CLIENTETableAdapter cLIENTETableAdapter1;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.TextBox nOMECLIENTETextBox;
        private System.Windows.Forms.TextBox cODSEXO_FKTextBox;
        private System.Windows.Forms.TextBox cODRUA_FKTextBox;
        private System.Windows.Forms.TextBox cODBAIRRO_FKTextBox;
        private System.Windows.Forms.TextBox cODCEP_FKTextBox;
        private System.Windows.Forms.TextBox cODCIDADE_FKTextBox;
        private System.Windows.Forms.TextBox sALARIOCLIENTETextBox;
        private System.Windows.Forms.TextBox cODTRABALHO_FKTextBox;
        private System.Windows.Forms.TextBox nUMEROCASATextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DateTimePicker dATANASCDateTimePicker;
        private System.Windows.Forms.TextBox cODCLIENTETextBox;
    }
}