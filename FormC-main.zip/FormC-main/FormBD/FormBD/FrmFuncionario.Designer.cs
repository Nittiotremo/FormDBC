﻿namespace FormBD
{
    partial class FrmFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFuncionario));
            System.Windows.Forms.Label cODFUNCIONARIOSLabel;
            System.Windows.Forms.Label nOMEFUNCIONARIOLabel;
            System.Windows.Forms.Label nUMEROCASALabel;
            System.Windows.Forms.Label cODRUA_FKLabel;
            System.Windows.Forms.Label cODBAIRRO_FKLabel;
            System.Windows.Forms.Label cODCEP_FKLabel;
            System.Windows.Forms.Label cODCIDADE_FKLabel;
            System.Windows.Forms.Label cODFUNCAO_FKLabel;
            System.Windows.Forms.Label sALARIOFUNCIONARIOLabel;
            System.Windows.Forms.Label cODLOJA_FKLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.fUNCIONARIOSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fUNCIONARIOSTableAdapter = new FormBD.FORM2DataSetTableAdapters.FUNCIONARIOSTableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.fUNCIONARIOSBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.fUNCIONARIOSBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cODFUNCIONARIOSNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.nOMEFUNCIONARIOTextBox = new System.Windows.Forms.TextBox();
            this.nUMEROCASATextBox = new System.Windows.Forms.TextBox();
            this.cODRUA_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODBAIRRO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODCEP_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODCIDADE_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODFUNCAO_FKTextBox = new System.Windows.Forms.TextBox();
            this.sALARIOFUNCIONARIOTextBox = new System.Windows.Forms.TextBox();
            this.cODLOJA_FKTextBox = new System.Windows.Forms.TextBox();
            this.fUNCIONARIOSDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            cODFUNCIONARIOSLabel = new System.Windows.Forms.Label();
            nOMEFUNCIONARIOLabel = new System.Windows.Forms.Label();
            nUMEROCASALabel = new System.Windows.Forms.Label();
            cODRUA_FKLabel = new System.Windows.Forms.Label();
            cODBAIRRO_FKLabel = new System.Windows.Forms.Label();
            cODCEP_FKLabel = new System.Windows.Forms.Label();
            cODCIDADE_FKLabel = new System.Windows.Forms.Label();
            cODFUNCAO_FKLabel = new System.Windows.Forms.Label();
            sALARIOFUNCIONARIOLabel = new System.Windows.Forms.Label();
            cODLOJA_FKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSBindingNavigator)).BeginInit();
            this.fUNCIONARIOSBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cODFUNCIONARIOSNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fUNCIONARIOSBindingSource
            // 
            this.fUNCIONARIOSBindingSource.DataMember = "FUNCIONARIOS";
            this.fUNCIONARIOSBindingSource.DataSource = this.fORM2DataSet;
            // 
            // fUNCIONARIOSTableAdapter
            // 
            this.fUNCIONARIOSTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = this.fUNCIONARIOSTableAdapter;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // fUNCIONARIOSBindingNavigator
            // 
            this.fUNCIONARIOSBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.fUNCIONARIOSBindingNavigator.BindingSource = this.fUNCIONARIOSBindingSource;
            this.fUNCIONARIOSBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.fUNCIONARIOSBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.fUNCIONARIOSBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.fUNCIONARIOSBindingNavigatorSaveItem});
            this.fUNCIONARIOSBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.fUNCIONARIOSBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.fUNCIONARIOSBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.fUNCIONARIOSBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.fUNCIONARIOSBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.fUNCIONARIOSBindingNavigator.Name = "fUNCIONARIOSBindingNavigator";
            this.fUNCIONARIOSBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.fUNCIONARIOSBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.fUNCIONARIOSBindingNavigator.TabIndex = 0;
            this.fUNCIONARIOSBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // fUNCIONARIOSBindingNavigatorSaveItem
            // 
            this.fUNCIONARIOSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fUNCIONARIOSBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("fUNCIONARIOSBindingNavigatorSaveItem.Image")));
            this.fUNCIONARIOSBindingNavigatorSaveItem.Name = "fUNCIONARIOSBindingNavigatorSaveItem";
            this.fUNCIONARIOSBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.fUNCIONARIOSBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.fUNCIONARIOSBindingNavigatorSaveItem.Click += new System.EventHandler(this.fUNCIONARIOSBindingNavigatorSaveItem_Click);
            // 
            // cODFUNCIONARIOSLabel
            // 
            cODFUNCIONARIOSLabel.AutoSize = true;
            cODFUNCIONARIOSLabel.Location = new System.Drawing.Point(23, 38);
            cODFUNCIONARIOSLabel.Name = "cODFUNCIONARIOSLabel";
            cODFUNCIONARIOSLabel.Size = new System.Drawing.Size(114, 13);
            cODFUNCIONARIOSLabel.TabIndex = 1;
            cODFUNCIONARIOSLabel.Text = "CODFUNCIONARIOS:";
            // 
            // cODFUNCIONARIOSNumericUpDown
            // 
            this.cODFUNCIONARIOSNumericUpDown.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.fUNCIONARIOSBindingSource, "CODFUNCIONARIOS", true));
            this.cODFUNCIONARIOSNumericUpDown.Location = new System.Drawing.Point(159, 38);
            this.cODFUNCIONARIOSNumericUpDown.Name = "cODFUNCIONARIOSNumericUpDown";
            this.cODFUNCIONARIOSNumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.cODFUNCIONARIOSNumericUpDown.TabIndex = 2;
            // 
            // nOMEFUNCIONARIOLabel
            // 
            nOMEFUNCIONARIOLabel.AutoSize = true;
            nOMEFUNCIONARIOLabel.Location = new System.Drawing.Point(23, 67);
            nOMEFUNCIONARIOLabel.Name = "nOMEFUNCIONARIOLabel";
            nOMEFUNCIONARIOLabel.Size = new System.Drawing.Size(116, 13);
            nOMEFUNCIONARIOLabel.TabIndex = 3;
            nOMEFUNCIONARIOLabel.Text = "NOMEFUNCIONARIO:";
            // 
            // nOMEFUNCIONARIOTextBox
            // 
            this.nOMEFUNCIONARIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "NOMEFUNCIONARIO", true));
            this.nOMEFUNCIONARIOTextBox.Location = new System.Drawing.Point(159, 64);
            this.nOMEFUNCIONARIOTextBox.Name = "nOMEFUNCIONARIOTextBox";
            this.nOMEFUNCIONARIOTextBox.Size = new System.Drawing.Size(120, 20);
            this.nOMEFUNCIONARIOTextBox.TabIndex = 4;
            // 
            // nUMEROCASALabel
            // 
            nUMEROCASALabel.AutoSize = true;
            nUMEROCASALabel.Location = new System.Drawing.Point(23, 93);
            nUMEROCASALabel.Name = "nUMEROCASALabel";
            nUMEROCASALabel.Size = new System.Drawing.Size(86, 13);
            nUMEROCASALabel.TabIndex = 5;
            nUMEROCASALabel.Text = "NUMEROCASA:";
            // 
            // nUMEROCASATextBox
            // 
            this.nUMEROCASATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "NUMEROCASA", true));
            this.nUMEROCASATextBox.Location = new System.Drawing.Point(159, 90);
            this.nUMEROCASATextBox.Name = "nUMEROCASATextBox";
            this.nUMEROCASATextBox.Size = new System.Drawing.Size(120, 20);
            this.nUMEROCASATextBox.TabIndex = 6;
            // 
            // cODRUA_FKLabel
            // 
            cODRUA_FKLabel.AutoSize = true;
            cODRUA_FKLabel.Location = new System.Drawing.Point(23, 119);
            cODRUA_FKLabel.Name = "cODRUA_FKLabel";
            cODRUA_FKLabel.Size = new System.Drawing.Size(72, 13);
            cODRUA_FKLabel.TabIndex = 7;
            cODRUA_FKLabel.Text = "CODRUA FK:";
            // 
            // cODRUA_FKTextBox
            // 
            this.cODRUA_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODRUA_FK", true));
            this.cODRUA_FKTextBox.Location = new System.Drawing.Point(159, 116);
            this.cODRUA_FKTextBox.Name = "cODRUA_FKTextBox";
            this.cODRUA_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODRUA_FKTextBox.TabIndex = 8;
            // 
            // cODBAIRRO_FKLabel
            // 
            cODBAIRRO_FKLabel.AutoSize = true;
            cODBAIRRO_FKLabel.Location = new System.Drawing.Point(23, 145);
            cODBAIRRO_FKLabel.Name = "cODBAIRRO_FKLabel";
            cODBAIRRO_FKLabel.Size = new System.Drawing.Size(90, 13);
            cODBAIRRO_FKLabel.TabIndex = 9;
            cODBAIRRO_FKLabel.Text = "CODBAIRRO FK:";
            // 
            // cODBAIRRO_FKTextBox
            // 
            this.cODBAIRRO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODBAIRRO_FK", true));
            this.cODBAIRRO_FKTextBox.Location = new System.Drawing.Point(159, 142);
            this.cODBAIRRO_FKTextBox.Name = "cODBAIRRO_FKTextBox";
            this.cODBAIRRO_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODBAIRRO_FKTextBox.TabIndex = 10;
            // 
            // cODCEP_FKLabel
            // 
            cODCEP_FKLabel.AutoSize = true;
            cODCEP_FKLabel.Location = new System.Drawing.Point(23, 171);
            cODCEP_FKLabel.Name = "cODCEP_FKLabel";
            cODCEP_FKLabel.Size = new System.Drawing.Size(70, 13);
            cODCEP_FKLabel.TabIndex = 11;
            cODCEP_FKLabel.Text = "CODCEP FK:";
            // 
            // cODCEP_FKTextBox
            // 
            this.cODCEP_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODCEP_FK", true));
            this.cODCEP_FKTextBox.Location = new System.Drawing.Point(159, 168);
            this.cODCEP_FKTextBox.Name = "cODCEP_FKTextBox";
            this.cODCEP_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODCEP_FKTextBox.TabIndex = 12;
            // 
            // cODCIDADE_FKLabel
            // 
            cODCIDADE_FKLabel.AutoSize = true;
            cODCIDADE_FKLabel.Location = new System.Drawing.Point(23, 197);
            cODCIDADE_FKLabel.Name = "cODCIDADE_FKLabel";
            cODCIDADE_FKLabel.Size = new System.Drawing.Size(89, 13);
            cODCIDADE_FKLabel.TabIndex = 13;
            cODCIDADE_FKLabel.Text = "CODCIDADE FK:";
            // 
            // cODCIDADE_FKTextBox
            // 
            this.cODCIDADE_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODCIDADE_FK", true));
            this.cODCIDADE_FKTextBox.Location = new System.Drawing.Point(159, 194);
            this.cODCIDADE_FKTextBox.Name = "cODCIDADE_FKTextBox";
            this.cODCIDADE_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODCIDADE_FKTextBox.TabIndex = 14;
            // 
            // cODFUNCAO_FKLabel
            // 
            cODFUNCAO_FKLabel.AutoSize = true;
            cODFUNCAO_FKLabel.Location = new System.Drawing.Point(23, 223);
            cODFUNCAO_FKLabel.Name = "cODFUNCAO_FKLabel";
            cODFUNCAO_FKLabel.Size = new System.Drawing.Size(93, 13);
            cODFUNCAO_FKLabel.TabIndex = 15;
            cODFUNCAO_FKLabel.Text = "CODFUNCAO FK:";
            // 
            // cODFUNCAO_FKTextBox
            // 
            this.cODFUNCAO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODFUNCAO_FK", true));
            this.cODFUNCAO_FKTextBox.Location = new System.Drawing.Point(159, 220);
            this.cODFUNCAO_FKTextBox.Name = "cODFUNCAO_FKTextBox";
            this.cODFUNCAO_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODFUNCAO_FKTextBox.TabIndex = 16;
            // 
            // sALARIOFUNCIONARIOLabel
            // 
            sALARIOFUNCIONARIOLabel.AutoSize = true;
            sALARIOFUNCIONARIOLabel.Location = new System.Drawing.Point(23, 249);
            sALARIOFUNCIONARIOLabel.Name = "sALARIOFUNCIONARIOLabel";
            sALARIOFUNCIONARIOLabel.Size = new System.Drawing.Size(130, 13);
            sALARIOFUNCIONARIOLabel.TabIndex = 17;
            sALARIOFUNCIONARIOLabel.Text = "SALARIOFUNCIONARIO:";
            // 
            // sALARIOFUNCIONARIOTextBox
            // 
            this.sALARIOFUNCIONARIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "SALARIOFUNCIONARIO", true));
            this.sALARIOFUNCIONARIOTextBox.Location = new System.Drawing.Point(159, 246);
            this.sALARIOFUNCIONARIOTextBox.Name = "sALARIOFUNCIONARIOTextBox";
            this.sALARIOFUNCIONARIOTextBox.Size = new System.Drawing.Size(120, 20);
            this.sALARIOFUNCIONARIOTextBox.TabIndex = 18;
            // 
            // cODLOJA_FKLabel
            // 
            cODLOJA_FKLabel.AutoSize = true;
            cODLOJA_FKLabel.Location = new System.Drawing.Point(23, 275);
            cODLOJA_FKLabel.Name = "cODLOJA_FKLabel";
            cODLOJA_FKLabel.Size = new System.Drawing.Size(75, 13);
            cODLOJA_FKLabel.TabIndex = 19;
            cODLOJA_FKLabel.Text = "CODLOJA FK:";
            // 
            // cODLOJA_FKTextBox
            // 
            this.cODLOJA_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fUNCIONARIOSBindingSource, "CODLOJA_FK", true));
            this.cODLOJA_FKTextBox.Location = new System.Drawing.Point(159, 272);
            this.cODLOJA_FKTextBox.Name = "cODLOJA_FKTextBox";
            this.cODLOJA_FKTextBox.Size = new System.Drawing.Size(120, 20);
            this.cODLOJA_FKTextBox.TabIndex = 20;
            // 
            // fUNCIONARIOSDataGridView
            // 
            this.fUNCIONARIOSDataGridView.AutoGenerateColumns = false;
            this.fUNCIONARIOSDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fUNCIONARIOSDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.fUNCIONARIOSDataGridView.DataSource = this.fUNCIONARIOSBindingSource;
            this.fUNCIONARIOSDataGridView.Location = new System.Drawing.Point(12, 324);
            this.fUNCIONARIOSDataGridView.Name = "fUNCIONARIOSDataGridView";
            this.fUNCIONARIOSDataGridView.Size = new System.Drawing.Size(776, 220);
            this.fUNCIONARIOSDataGridView.TabIndex = 21;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODFUNCIONARIOS";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODFUNCIONARIOS";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMEFUNCIONARIO";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMEFUNCIONARIO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NUMEROCASA";
            this.dataGridViewTextBoxColumn3.HeaderText = "NUMEROCASA";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODRUA_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODRUA_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn5.HeaderText = "CODBAIRRO_FK";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CODCEP_FK";
            this.dataGridViewTextBoxColumn6.HeaderText = "CODCEP_FK";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn7.HeaderText = "CODCIDADE_FK";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "CODFUNCAO_FK";
            this.dataGridViewTextBoxColumn8.HeaderText = "CODFUNCAO_FK";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "SALARIOFUNCIONARIO";
            this.dataGridViewTextBoxColumn9.HeaderText = "SALARIOFUNCIONARIO";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CODLOJA_FK";
            this.dataGridViewTextBoxColumn10.HeaderText = "CODLOJA_FK";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // FrmFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 581);
            this.Controls.Add(this.fUNCIONARIOSDataGridView);
            this.Controls.Add(cODFUNCIONARIOSLabel);
            this.Controls.Add(this.cODFUNCIONARIOSNumericUpDown);
            this.Controls.Add(nOMEFUNCIONARIOLabel);
            this.Controls.Add(this.nOMEFUNCIONARIOTextBox);
            this.Controls.Add(nUMEROCASALabel);
            this.Controls.Add(this.nUMEROCASATextBox);
            this.Controls.Add(cODRUA_FKLabel);
            this.Controls.Add(this.cODRUA_FKTextBox);
            this.Controls.Add(cODBAIRRO_FKLabel);
            this.Controls.Add(this.cODBAIRRO_FKTextBox);
            this.Controls.Add(cODCEP_FKLabel);
            this.Controls.Add(this.cODCEP_FKTextBox);
            this.Controls.Add(cODCIDADE_FKLabel);
            this.Controls.Add(this.cODCIDADE_FKTextBox);
            this.Controls.Add(cODFUNCAO_FKLabel);
            this.Controls.Add(this.cODFUNCAO_FKTextBox);
            this.Controls.Add(sALARIOFUNCIONARIOLabel);
            this.Controls.Add(this.sALARIOFUNCIONARIOTextBox);
            this.Controls.Add(cODLOJA_FKLabel);
            this.Controls.Add(this.cODLOJA_FKTextBox);
            this.Controls.Add(this.fUNCIONARIOSBindingNavigator);
            this.Name = "FrmFuncionario";
            this.Text = "FrmFuncionario";
            this.Load += new System.EventHandler(this.FrmFuncionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSBindingNavigator)).EndInit();
            this.fUNCIONARIOSBindingNavigator.ResumeLayout(false);
            this.fUNCIONARIOSBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cODFUNCIONARIOSNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fUNCIONARIOSDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource fUNCIONARIOSBindingSource;
        private FORM2DataSetTableAdapters.FUNCIONARIOSTableAdapter fUNCIONARIOSTableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator fUNCIONARIOSBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton fUNCIONARIOSBindingNavigatorSaveItem;
        private System.Windows.Forms.NumericUpDown cODFUNCIONARIOSNumericUpDown;
        private System.Windows.Forms.TextBox nOMEFUNCIONARIOTextBox;
        private System.Windows.Forms.TextBox nUMEROCASATextBox;
        private System.Windows.Forms.TextBox cODRUA_FKTextBox;
        private System.Windows.Forms.TextBox cODBAIRRO_FKTextBox;
        private System.Windows.Forms.TextBox cODCEP_FKTextBox;
        private System.Windows.Forms.TextBox cODCIDADE_FKTextBox;
        private System.Windows.Forms.TextBox cODFUNCAO_FKTextBox;
        private System.Windows.Forms.TextBox sALARIOFUNCIONARIOTextBox;
        private System.Windows.Forms.TextBox cODLOJA_FKTextBox;
        private System.Windows.Forms.DataGridView fUNCIONARIOSDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
    }
}