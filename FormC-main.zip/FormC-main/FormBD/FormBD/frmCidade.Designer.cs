﻿namespace FormBD
{
    partial class frmCidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCidade));
            System.Windows.Forms.Label nOMECIDADELabel;
            System.Windows.Forms.Label cODCIDADELabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.cIDADEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cIDADETableAdapter = new FormBD.FORM2DataSetTableAdapters.CIDADETableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.uFTableAdapter = new FormBD.FORM2DataSetTableAdapters.UFTableAdapter();
            this.cIDADEBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cIDADEBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.uFBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nOMECIDADETextBox = new System.Windows.Forms.TextBox();
            this.cODCIDADENumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.cIDADEDataGridView = new System.Windows.Forms.DataGridView();
            this.cIDADEBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nOMECIDADELabel = new System.Windows.Forms.Label();
            cODCIDADELabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingNavigator)).BeginInit();
            this.cIDADEBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uFBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cODCIDADENumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cIDADEBindingSource
            // 
            this.cIDADEBindingSource.DataMember = "CIDADE";
            this.cIDADEBindingSource.DataSource = this.fORM2DataSet;
            // 
            // cIDADETableAdapter
            // 
            this.cIDADETableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = this.cIDADETableAdapter;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = this.uFTableAdapter;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // uFTableAdapter
            // 
            this.uFTableAdapter.ClearBeforeFill = true;
            // 
            // cIDADEBindingNavigator
            // 
            this.cIDADEBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cIDADEBindingNavigator.BindingSource = this.cIDADEBindingSource;
            this.cIDADEBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cIDADEBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cIDADEBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cIDADEBindingNavigatorSaveItem});
            this.cIDADEBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cIDADEBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cIDADEBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cIDADEBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cIDADEBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cIDADEBindingNavigator.Name = "cIDADEBindingNavigator";
            this.cIDADEBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cIDADEBindingNavigator.Size = new System.Drawing.Size(398, 25);
            this.cIDADEBindingNavigator.TabIndex = 0;
            this.cIDADEBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // cIDADEBindingNavigatorSaveItem
            // 
            this.cIDADEBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cIDADEBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cIDADEBindingNavigatorSaveItem.Image")));
            this.cIDADEBindingNavigatorSaveItem.Name = "cIDADEBindingNavigatorSaveItem";
            this.cIDADEBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.cIDADEBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.cIDADEBindingNavigatorSaveItem.Click += new System.EventHandler(this.cIDADEBindingNavigatorSaveItem_Click);
            // 
            // uFBindingSource
            // 
            this.uFBindingSource.DataMember = "UF";
            this.uFBindingSource.DataSource = this.fORM2DataSet;
            // 
            // nOMECIDADETextBox
            // 
            this.nOMECIDADETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cIDADEBindingSource, "NOMECIDADE", true));
            this.nOMECIDADETextBox.Location = new System.Drawing.Point(100, 85);
            this.nOMECIDADETextBox.Name = "nOMECIDADETextBox";
            this.nOMECIDADETextBox.Size = new System.Drawing.Size(120, 20);
            this.nOMECIDADETextBox.TabIndex = 4;
            // 
            // nOMECIDADELabel
            // 
            nOMECIDADELabel.AutoSize = true;
            nOMECIDADELabel.Location = new System.Drawing.Point(12, 88);
            nOMECIDADELabel.Name = "nOMECIDADELabel";
            nOMECIDADELabel.Size = new System.Drawing.Size(82, 13);
            nOMECIDADELabel.TabIndex = 3;
            nOMECIDADELabel.Text = "NOMECIDADE:";
            // 
            // cODCIDADENumericUpDown
            // 
            this.cODCIDADENumericUpDown.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.cIDADEBindingSource, "CODCIDADE", true));
            this.cODCIDADENumericUpDown.Location = new System.Drawing.Point(100, 59);
            this.cODCIDADENumericUpDown.Name = "cODCIDADENumericUpDown";
            this.cODCIDADENumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.cODCIDADENumericUpDown.TabIndex = 2;
            // 
            // cODCIDADELabel
            // 
            cODCIDADELabel.AutoSize = true;
            cODCIDADELabel.Location = new System.Drawing.Point(12, 59);
            cODCIDADELabel.Name = "cODCIDADELabel";
            cODCIDADELabel.Size = new System.Drawing.Size(73, 13);
            cODCIDADELabel.TabIndex = 1;
            cODCIDADELabel.Text = "CODCIDADE:";
            // 
            // cIDADEDataGridView
            // 
            this.cIDADEDataGridView.AutoGenerateColumns = false;
            this.cIDADEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cIDADEDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.cIDADEDataGridView.DataSource = this.cIDADEBindingSource;
            this.cIDADEDataGridView.Location = new System.Drawing.Point(0, 218);
            this.cIDADEDataGridView.Name = "cIDADEDataGridView";
            this.cIDADEDataGridView.Size = new System.Drawing.Size(378, 220);
            this.cIDADEDataGridView.TabIndex = 7;
            // 
            // cIDADEBindingSource1
            // 
            this.cIDADEBindingSource1.DataMember = "FK__CIDADE__CODUF_FK__656C112C";
            this.cIDADEBindingSource1.DataSource = this.uFBindingSource;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODCIDADE";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODCIDADE";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMECIDADE";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMECIDADE";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // frmCidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 458);
            this.Controls.Add(this.cIDADEDataGridView);
            this.Controls.Add(cODCIDADELabel);
            this.Controls.Add(this.cODCIDADENumericUpDown);
            this.Controls.Add(nOMECIDADELabel);
            this.Controls.Add(this.nOMECIDADETextBox);
            this.Controls.Add(this.cIDADEBindingNavigator);
            this.Name = "frmCidade";
            this.Text = "frmCidade";
            this.Load += new System.EventHandler(this.frmCidade_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingNavigator)).EndInit();
            this.cIDADEBindingNavigator.ResumeLayout(false);
            this.cIDADEBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uFBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cODCIDADENumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cIDADEBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource cIDADEBindingSource;
        private FORM2DataSetTableAdapters.CIDADETableAdapter cIDADETableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cIDADEBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cIDADEBindingNavigatorSaveItem;
        private FORM2DataSetTableAdapters.UFTableAdapter uFTableAdapter;
        private System.Windows.Forms.BindingSource uFBindingSource;
        private System.Windows.Forms.TextBox nOMECIDADETextBox;
        private System.Windows.Forms.NumericUpDown cODCIDADENumericUpDown;
        private System.Windows.Forms.DataGridView cIDADEDataGridView;
        private System.Windows.Forms.BindingSource cIDADEBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}