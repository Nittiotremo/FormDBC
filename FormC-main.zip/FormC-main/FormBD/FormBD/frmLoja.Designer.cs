﻿namespace FormBD
{
    partial class frmLoja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLoja));
            System.Windows.Forms.Label cODLOJALabel;
            System.Windows.Forms.Label nOMELOJALabel;
            System.Windows.Forms.Label cNPJLabel;
            System.Windows.Forms.Label nOMEFANTASIALabel;
            System.Windows.Forms.Label rAZAOSOCIALLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.lOJABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lOJATableAdapter = new FormBD.FORM2DataSetTableAdapters.LOJATableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.lOJABindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.lOJABindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cODLOJATextBox = new System.Windows.Forms.TextBox();
            this.nOMELOJATextBox = new System.Windows.Forms.TextBox();
            this.cNPJTextBox = new System.Windows.Forms.TextBox();
            this.nOMEFANTASIATextBox = new System.Windows.Forms.TextBox();
            this.rAZAOSOCIALTextBox = new System.Windows.Forms.TextBox();
            this.lOJADataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            cODLOJALabel = new System.Windows.Forms.Label();
            nOMELOJALabel = new System.Windows.Forms.Label();
            cNPJLabel = new System.Windows.Forms.Label();
            nOMEFANTASIALabel = new System.Windows.Forms.Label();
            rAZAOSOCIALLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOJABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOJABindingNavigator)).BeginInit();
            this.lOJABindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lOJADataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lOJABindingSource
            // 
            this.lOJABindingSource.DataMember = "LOJA";
            this.lOJABindingSource.DataSource = this.fORM2DataSet;
            // 
            // lOJATableAdapter
            // 
            this.lOJATableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = this.lOJATableAdapter;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // lOJABindingNavigator
            // 
            this.lOJABindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.lOJABindingNavigator.BindingSource = this.lOJABindingSource;
            this.lOJABindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.lOJABindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.lOJABindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.lOJABindingNavigatorSaveItem});
            this.lOJABindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.lOJABindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.lOJABindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.lOJABindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.lOJABindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.lOJABindingNavigator.Name = "lOJABindingNavigator";
            this.lOJABindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.lOJABindingNavigator.Size = new System.Drawing.Size(574, 25);
            this.lOJABindingNavigator.TabIndex = 0;
            this.lOJABindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // lOJABindingNavigatorSaveItem
            // 
            this.lOJABindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lOJABindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("lOJABindingNavigatorSaveItem.Image")));
            this.lOJABindingNavigatorSaveItem.Name = "lOJABindingNavigatorSaveItem";
            this.lOJABindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.lOJABindingNavigatorSaveItem.Text = "Salvar Dados";
            this.lOJABindingNavigatorSaveItem.Click += new System.EventHandler(this.lOJABindingNavigatorSaveItem_Click);
            // 
            // cODLOJALabel
            // 
            cODLOJALabel.AutoSize = true;
            cODLOJALabel.Location = new System.Drawing.Point(9, 39);
            cODLOJALabel.Name = "cODLOJALabel";
            cODLOJALabel.Size = new System.Drawing.Size(59, 13);
            cODLOJALabel.TabIndex = 1;
            cODLOJALabel.Text = "CODLOJA:";
            // 
            // cODLOJATextBox
            // 
            this.cODLOJATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lOJABindingSource, "CODLOJA", true));
            this.cODLOJATextBox.Location = new System.Drawing.Point(109, 36);
            this.cODLOJATextBox.Name = "cODLOJATextBox";
            this.cODLOJATextBox.Size = new System.Drawing.Size(100, 20);
            this.cODLOJATextBox.TabIndex = 2;
            // 
            // nOMELOJALabel
            // 
            nOMELOJALabel.AutoSize = true;
            nOMELOJALabel.Location = new System.Drawing.Point(9, 65);
            nOMELOJALabel.Name = "nOMELOJALabel";
            nOMELOJALabel.Size = new System.Drawing.Size(68, 13);
            nOMELOJALabel.TabIndex = 3;
            nOMELOJALabel.Text = "NOMELOJA:";
            // 
            // nOMELOJATextBox
            // 
            this.nOMELOJATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lOJABindingSource, "NOMELOJA", true));
            this.nOMELOJATextBox.Location = new System.Drawing.Point(109, 62);
            this.nOMELOJATextBox.Name = "nOMELOJATextBox";
            this.nOMELOJATextBox.Size = new System.Drawing.Size(100, 20);
            this.nOMELOJATextBox.TabIndex = 4;
            // 
            // cNPJLabel
            // 
            cNPJLabel.AutoSize = true;
            cNPJLabel.Location = new System.Drawing.Point(9, 91);
            cNPJLabel.Name = "cNPJLabel";
            cNPJLabel.Size = new System.Drawing.Size(37, 13);
            cNPJLabel.TabIndex = 5;
            cNPJLabel.Text = "CNPJ:";
            // 
            // cNPJTextBox
            // 
            this.cNPJTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lOJABindingSource, "CNPJ", true));
            this.cNPJTextBox.Location = new System.Drawing.Point(109, 88);
            this.cNPJTextBox.Name = "cNPJTextBox";
            this.cNPJTextBox.Size = new System.Drawing.Size(100, 20);
            this.cNPJTextBox.TabIndex = 6;
            // 
            // nOMEFANTASIALabel
            // 
            nOMEFANTASIALabel.AutoSize = true;
            nOMEFANTASIALabel.Location = new System.Drawing.Point(9, 117);
            nOMEFANTASIALabel.Name = "nOMEFANTASIALabel";
            nOMEFANTASIALabel.Size = new System.Drawing.Size(94, 13);
            nOMEFANTASIALabel.TabIndex = 7;
            nOMEFANTASIALabel.Text = "NOMEFANTASIA:";
            // 
            // nOMEFANTASIATextBox
            // 
            this.nOMEFANTASIATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lOJABindingSource, "NOMEFANTASIA", true));
            this.nOMEFANTASIATextBox.Location = new System.Drawing.Point(109, 114);
            this.nOMEFANTASIATextBox.Name = "nOMEFANTASIATextBox";
            this.nOMEFANTASIATextBox.Size = new System.Drawing.Size(100, 20);
            this.nOMEFANTASIATextBox.TabIndex = 8;
            // 
            // rAZAOSOCIALLabel
            // 
            rAZAOSOCIALLabel.AutoSize = true;
            rAZAOSOCIALLabel.Location = new System.Drawing.Point(9, 143);
            rAZAOSOCIALLabel.Name = "rAZAOSOCIALLabel";
            rAZAOSOCIALLabel.Size = new System.Drawing.Size(85, 13);
            rAZAOSOCIALLabel.TabIndex = 9;
            rAZAOSOCIALLabel.Text = "RAZAOSOCIAL:";
            // 
            // rAZAOSOCIALTextBox
            // 
            this.rAZAOSOCIALTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lOJABindingSource, "RAZAOSOCIAL", true));
            this.rAZAOSOCIALTextBox.Location = new System.Drawing.Point(109, 140);
            this.rAZAOSOCIALTextBox.Name = "rAZAOSOCIALTextBox";
            this.rAZAOSOCIALTextBox.Size = new System.Drawing.Size(100, 20);
            this.rAZAOSOCIALTextBox.TabIndex = 10;
            // 
            // lOJADataGridView
            // 
            this.lOJADataGridView.AutoGenerateColumns = false;
            this.lOJADataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lOJADataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.lOJADataGridView.DataSource = this.lOJABindingSource;
            this.lOJADataGridView.Location = new System.Drawing.Point(12, 188);
            this.lOJADataGridView.Name = "lOJADataGridView";
            this.lOJADataGridView.Size = new System.Drawing.Size(550, 220);
            this.lOJADataGridView.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODLOJA";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODLOJA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NOMELOJA";
            this.dataGridViewTextBoxColumn2.HeaderText = "NOMELOJA";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "CNPJ";
            this.dataGridViewTextBoxColumn3.HeaderText = "CNPJ";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NOMEFANTASIA";
            this.dataGridViewTextBoxColumn4.HeaderText = "NOMEFANTASIA";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "RAZAOSOCIAL";
            this.dataGridViewTextBoxColumn5.HeaderText = "RAZAOSOCIAL";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // frmLoja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 422);
            this.Controls.Add(this.lOJADataGridView);
            this.Controls.Add(cODLOJALabel);
            this.Controls.Add(this.cODLOJATextBox);
            this.Controls.Add(nOMELOJALabel);
            this.Controls.Add(this.nOMELOJATextBox);
            this.Controls.Add(cNPJLabel);
            this.Controls.Add(this.cNPJTextBox);
            this.Controls.Add(nOMEFANTASIALabel);
            this.Controls.Add(this.nOMEFANTASIATextBox);
            this.Controls.Add(rAZAOSOCIALLabel);
            this.Controls.Add(this.rAZAOSOCIALTextBox);
            this.Controls.Add(this.lOJABindingNavigator);
            this.Name = "frmLoja";
            this.Text = "frmLoja";
            this.Load += new System.EventHandler(this.frmLoja_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOJABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOJABindingNavigator)).EndInit();
            this.lOJABindingNavigator.ResumeLayout(false);
            this.lOJABindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lOJADataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource lOJABindingSource;
        private FORM2DataSetTableAdapters.LOJATableAdapter lOJATableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator lOJABindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton lOJABindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox cODLOJATextBox;
        private System.Windows.Forms.TextBox nOMELOJATextBox;
        private System.Windows.Forms.TextBox cNPJTextBox;
        private System.Windows.Forms.TextBox nOMEFANTASIATextBox;
        private System.Windows.Forms.TextBox rAZAOSOCIALTextBox;
        private System.Windows.Forms.DataGridView lOJADataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}