﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormBD
{
    public partial class frmCompraProduto : Form
    {
        public frmCompraProduto()
        {
            InitializeComponent();
        }

        private void cOMPRAPRODUTOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cOMPRAPRODUTOBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.fORM2DataSet);

        }

        private void frmCompraProduto_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'fORM2DataSet.COMPRAPRODUTO'. Você pode movê-la ou removê-la conforme necessário.
            this.cOMPRAPRODUTOTableAdapter.Fill(this.fORM2DataSet.COMPRAPRODUTO);

        }
    }
}
