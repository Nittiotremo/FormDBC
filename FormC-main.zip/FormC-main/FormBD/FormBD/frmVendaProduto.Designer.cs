﻿namespace FormBD
{
    partial class frmVendaProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVendaProduto));
            System.Windows.Forms.Label cODVENDALabel;
            System.Windows.Forms.Label dATAVENDALabel;
            System.Windows.Forms.Label cODCLIENTE_FKLabel;
            System.Windows.Forms.Label cODFUNCIONARIO_FKLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.vENDAPRODUTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vENDAPRODUTOTableAdapter = new FormBD.FORM2DataSetTableAdapters.VENDAPRODUTOTableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.vENDAPRODUTOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.vENDAPRODUTOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cODVENDATextBox = new System.Windows.Forms.TextBox();
            this.dATAVENDADateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cODCLIENTE_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODFUNCIONARIO_FKTextBox = new System.Windows.Forms.TextBox();
            this.vENDAPRODUTODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            cODVENDALabel = new System.Windows.Forms.Label();
            dATAVENDALabel = new System.Windows.Forms.Label();
            cODCLIENTE_FKLabel = new System.Windows.Forms.Label();
            cODFUNCIONARIO_FKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTOBindingNavigator)).BeginInit();
            this.vENDAPRODUTOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vENDAPRODUTOBindingSource
            // 
            this.vENDAPRODUTOBindingSource.DataMember = "VENDAPRODUTO";
            this.vENDAPRODUTOBindingSource.DataSource = this.fORM2DataSet;
            // 
            // vENDAPRODUTOTableAdapter
            // 
            this.vENDAPRODUTOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = null;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = this.vENDAPRODUTOTableAdapter;
            // 
            // vENDAPRODUTOBindingNavigator
            // 
            this.vENDAPRODUTOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.vENDAPRODUTOBindingNavigator.BindingSource = this.vENDAPRODUTOBindingSource;
            this.vENDAPRODUTOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.vENDAPRODUTOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.vENDAPRODUTOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.vENDAPRODUTOBindingNavigatorSaveItem});
            this.vENDAPRODUTOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.vENDAPRODUTOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.vENDAPRODUTOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.vENDAPRODUTOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.vENDAPRODUTOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.vENDAPRODUTOBindingNavigator.Name = "vENDAPRODUTOBindingNavigator";
            this.vENDAPRODUTOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.vENDAPRODUTOBindingNavigator.Size = new System.Drawing.Size(480, 25);
            this.vENDAPRODUTOBindingNavigator.TabIndex = 0;
            this.vENDAPRODUTOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // vENDAPRODUTOBindingNavigatorSaveItem
            // 
            this.vENDAPRODUTOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.vENDAPRODUTOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("vENDAPRODUTOBindingNavigatorSaveItem.Image")));
            this.vENDAPRODUTOBindingNavigatorSaveItem.Name = "vENDAPRODUTOBindingNavigatorSaveItem";
            this.vENDAPRODUTOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.vENDAPRODUTOBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.vENDAPRODUTOBindingNavigatorSaveItem.Click += new System.EventHandler(this.vENDAPRODUTOBindingNavigatorSaveItem_Click);
            // 
            // cODVENDALabel
            // 
            cODVENDALabel.AutoSize = true;
            cODVENDALabel.Location = new System.Drawing.Point(12, 47);
            cODVENDALabel.Name = "cODVENDALabel";
            cODVENDALabel.Size = new System.Drawing.Size(70, 13);
            cODVENDALabel.TabIndex = 1;
            cODVENDALabel.Text = "CODVENDA:";
            // 
            // cODVENDATextBox
            // 
            this.cODVENDATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vENDAPRODUTOBindingSource, "CODVENDA", true));
            this.cODVENDATextBox.Location = new System.Drawing.Point(141, 44);
            this.cODVENDATextBox.Name = "cODVENDATextBox";
            this.cODVENDATextBox.Size = new System.Drawing.Size(200, 20);
            this.cODVENDATextBox.TabIndex = 2;
            // 
            // dATAVENDALabel
            // 
            dATAVENDALabel.AutoSize = true;
            dATAVENDALabel.Location = new System.Drawing.Point(12, 74);
            dATAVENDALabel.Name = "dATAVENDALabel";
            dATAVENDALabel.Size = new System.Drawing.Size(76, 13);
            dATAVENDALabel.TabIndex = 3;
            dATAVENDALabel.Text = "DATAVENDA:";
            // 
            // dATAVENDADateTimePicker
            // 
            this.dATAVENDADateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.vENDAPRODUTOBindingSource, "DATAVENDA", true));
            this.dATAVENDADateTimePicker.Location = new System.Drawing.Point(141, 70);
            this.dATAVENDADateTimePicker.Name = "dATAVENDADateTimePicker";
            this.dATAVENDADateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dATAVENDADateTimePicker.TabIndex = 4;
            // 
            // cODCLIENTE_FKLabel
            // 
            cODCLIENTE_FKLabel.AutoSize = true;
            cODCLIENTE_FKLabel.Location = new System.Drawing.Point(12, 99);
            cODCLIENTE_FKLabel.Name = "cODCLIENTE_FKLabel";
            cODCLIENTE_FKLabel.Size = new System.Drawing.Size(94, 13);
            cODCLIENTE_FKLabel.TabIndex = 5;
            cODCLIENTE_FKLabel.Text = "CODCLIENTE FK:";
            // 
            // cODCLIENTE_FKTextBox
            // 
            this.cODCLIENTE_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vENDAPRODUTOBindingSource, "CODCLIENTE_FK", true));
            this.cODCLIENTE_FKTextBox.Location = new System.Drawing.Point(141, 96);
            this.cODCLIENTE_FKTextBox.Name = "cODCLIENTE_FKTextBox";
            this.cODCLIENTE_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODCLIENTE_FKTextBox.TabIndex = 6;
            // 
            // cODFUNCIONARIO_FKLabel
            // 
            cODFUNCIONARIO_FKLabel.AutoSize = true;
            cODFUNCIONARIO_FKLabel.Location = new System.Drawing.Point(12, 125);
            cODFUNCIONARIO_FKLabel.Name = "cODFUNCIONARIO_FKLabel";
            cODFUNCIONARIO_FKLabel.Size = new System.Drawing.Size(123, 13);
            cODFUNCIONARIO_FKLabel.TabIndex = 7;
            cODFUNCIONARIO_FKLabel.Text = "CODFUNCIONARIO FK:";
            // 
            // cODFUNCIONARIO_FKTextBox
            // 
            this.cODFUNCIONARIO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vENDAPRODUTOBindingSource, "CODFUNCIONARIO_FK", true));
            this.cODFUNCIONARIO_FKTextBox.Location = new System.Drawing.Point(141, 122);
            this.cODFUNCIONARIO_FKTextBox.Name = "cODFUNCIONARIO_FKTextBox";
            this.cODFUNCIONARIO_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODFUNCIONARIO_FKTextBox.TabIndex = 8;
            // 
            // vENDAPRODUTODataGridView
            // 
            this.vENDAPRODUTODataGridView.AutoGenerateColumns = false;
            this.vENDAPRODUTODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vENDAPRODUTODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.vENDAPRODUTODataGridView.DataSource = this.vENDAPRODUTOBindingSource;
            this.vENDAPRODUTODataGridView.Location = new System.Drawing.Point(12, 182);
            this.vENDAPRODUTODataGridView.Name = "vENDAPRODUTODataGridView";
            this.vENDAPRODUTODataGridView.Size = new System.Drawing.Size(458, 220);
            this.vENDAPRODUTODataGridView.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODVENDA";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODVENDA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DATAVENDA";
            this.dataGridViewTextBoxColumn2.HeaderText = "DATAVENDA";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "CODCLIENTE_FK";
            this.dataGridViewTextBoxColumn3.HeaderText = "CODCLIENTE_FK";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // frmVendaProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 413);
            this.Controls.Add(this.vENDAPRODUTODataGridView);
            this.Controls.Add(cODVENDALabel);
            this.Controls.Add(this.cODVENDATextBox);
            this.Controls.Add(dATAVENDALabel);
            this.Controls.Add(this.dATAVENDADateTimePicker);
            this.Controls.Add(cODCLIENTE_FKLabel);
            this.Controls.Add(this.cODCLIENTE_FKTextBox);
            this.Controls.Add(cODFUNCIONARIO_FKLabel);
            this.Controls.Add(this.cODFUNCIONARIO_FKTextBox);
            this.Controls.Add(this.vENDAPRODUTOBindingNavigator);
            this.Name = "frmVendaProduto";
            this.Text = "frmVendaProduto";
            this.Load += new System.EventHandler(this.frmVendaProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTOBindingNavigator)).EndInit();
            this.vENDAPRODUTOBindingNavigator.ResumeLayout(false);
            this.vENDAPRODUTOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vENDAPRODUTODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource vENDAPRODUTOBindingSource;
        private FORM2DataSetTableAdapters.VENDAPRODUTOTableAdapter vENDAPRODUTOTableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator vENDAPRODUTOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton vENDAPRODUTOBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox cODVENDATextBox;
        private System.Windows.Forms.DateTimePicker dATAVENDADateTimePicker;
        private System.Windows.Forms.TextBox cODCLIENTE_FKTextBox;
        private System.Windows.Forms.TextBox cODFUNCIONARIO_FKTextBox;
        private System.Windows.Forms.DataGridView vENDAPRODUTODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}