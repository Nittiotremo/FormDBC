﻿namespace FormBD
{
    partial class frmParcelaVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmParcelaVenda));
            System.Windows.Forms.Label cODPARCELALabel;
            System.Windows.Forms.Label dATAVENCIMENTOLabel;
            System.Windows.Forms.Label vALORPARCELALabel;
            System.Windows.Forms.Label cODFUNCIONARIO_FKLabel;
            System.Windows.Forms.Label cODSITUACAO_FKLabel;
            System.Windows.Forms.Label cODVENDA_FKLabel;
            this.fORM2DataSet = new FormBD.FORM2DataSet();
            this.pARCELAVENDABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pARCELAVENDATableAdapter = new FormBD.FORM2DataSetTableAdapters.PARCELAVENDATableAdapter();
            this.tableAdapterManager = new FormBD.FORM2DataSetTableAdapters.TableAdapterManager();
            this.pARCELAVENDABindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.pARCELAVENDABindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.pARCELAVENDADataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cODPARCELATextBox = new System.Windows.Forms.TextBox();
            this.dATAVENCIMENTODateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.vALORPARCELATextBox = new System.Windows.Forms.TextBox();
            this.cODFUNCIONARIO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODSITUACAO_FKTextBox = new System.Windows.Forms.TextBox();
            this.cODVENDA_FKTextBox = new System.Windows.Forms.TextBox();
            cODPARCELALabel = new System.Windows.Forms.Label();
            dATAVENCIMENTOLabel = new System.Windows.Forms.Label();
            vALORPARCELALabel = new System.Windows.Forms.Label();
            cODFUNCIONARIO_FKLabel = new System.Windows.Forms.Label();
            cODSITUACAO_FKLabel = new System.Windows.Forms.Label();
            cODVENDA_FKLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDABindingNavigator)).BeginInit();
            this.pARCELAVENDABindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDADataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fORM2DataSet
            // 
            this.fORM2DataSet.DataSetName = "FORM2DataSet";
            this.fORM2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pARCELAVENDABindingSource
            // 
            this.pARCELAVENDABindingSource.DataMember = "PARCELAVENDA";
            this.pARCELAVENDABindingSource.DataSource = this.fORM2DataSet;
            // 
            // pARCELAVENDATableAdapter
            // 
            this.pARCELAVENDATableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ACESSOTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BAIRROTableAdapter = null;
            this.tableAdapterManager.CEPTableAdapter = null;
            this.tableAdapterManager.CIDADETableAdapter = null;
            this.tableAdapterManager.CLIENTETableAdapter = null;
            this.tableAdapterManager.COMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.CONTROLELOGSISTEMATableAdapter = null;
            this.tableAdapterManager.FORNECEDORTableAdapter = null;
            this.tableAdapterManager.FUNCAOTableAdapter = null;
            this.tableAdapterManager.FUNCIONARIOSTableAdapter = null;
            this.tableAdapterManager.IMAGENSTableAdapter = null;
            this.tableAdapterManager.ITENSACESSOLOGINTableAdapter = null;
            this.tableAdapterManager.ITENSCOMPRAPRODUTOTableAdapter = null;
            this.tableAdapterManager.ITENSTELCLIENTETableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFORNECEDORTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONEFUNCIONARIOTableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONELOJATableAdapter = null;
            this.tableAdapterManager.ITENSTELEFONETRABALHOTableAdapter = null;
            this.tableAdapterManager.ITENSVENDAPRODUTOTableAdapter = null;
            this.tableAdapterManager.LOGINTableAdapter = null;
            this.tableAdapterManager.LOJATableAdapter = null;
            this.tableAdapterManager.MARCATableAdapter = null;
            this.tableAdapterManager.OPERADORATableAdapter = null;
            this.tableAdapterManager.PARCELACOMPRATableAdapter = null;
            this.tableAdapterManager.PARCELAVENDATableAdapter = this.pARCELAVENDATableAdapter;
            this.tableAdapterManager.PRODUTOTableAdapter = null;
            this.tableAdapterManager.RUATableAdapter = null;
            this.tableAdapterManager.SEXOTableAdapter = null;
            this.tableAdapterManager.SITUACAOTableAdapter = null;
            this.tableAdapterManager.TELEFONETableAdapter = null;
            this.tableAdapterManager.TIPOTableAdapter = null;
            this.tableAdapterManager.TRABALHOTableAdapter = null;
            this.tableAdapterManager.UFTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = FormBD.FORM2DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VENDAPRODUTOTableAdapter = null;
            // 
            // pARCELAVENDABindingNavigator
            // 
            this.pARCELAVENDABindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.pARCELAVENDABindingNavigator.BindingSource = this.pARCELAVENDABindingSource;
            this.pARCELAVENDABindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.pARCELAVENDABindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.pARCELAVENDABindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.pARCELAVENDABindingNavigatorSaveItem});
            this.pARCELAVENDABindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.pARCELAVENDABindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.pARCELAVENDABindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.pARCELAVENDABindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.pARCELAVENDABindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.pARCELAVENDABindingNavigator.Name = "pARCELAVENDABindingNavigator";
            this.pARCELAVENDABindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.pARCELAVENDABindingNavigator.Size = new System.Drawing.Size(673, 25);
            this.pARCELAVENDABindingNavigator.TabIndex = 0;
            this.pARCELAVENDABindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // pARCELAVENDABindingNavigatorSaveItem
            // 
            this.pARCELAVENDABindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pARCELAVENDABindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("pARCELAVENDABindingNavigatorSaveItem.Image")));
            this.pARCELAVENDABindingNavigatorSaveItem.Name = "pARCELAVENDABindingNavigatorSaveItem";
            this.pARCELAVENDABindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.pARCELAVENDABindingNavigatorSaveItem.Text = "Salvar Dados";
            this.pARCELAVENDABindingNavigatorSaveItem.Click += new System.EventHandler(this.pARCELAVENDABindingNavigatorSaveItem_Click);
            // 
            // pARCELAVENDADataGridView
            // 
            this.pARCELAVENDADataGridView.AutoGenerateColumns = false;
            this.pARCELAVENDADataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pARCELAVENDADataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.pARCELAVENDADataGridView.DataSource = this.pARCELAVENDABindingSource;
            this.pARCELAVENDADataGridView.Location = new System.Drawing.Point(0, 198);
            this.pARCELAVENDADataGridView.Name = "pARCELAVENDADataGridView";
            this.pARCELAVENDADataGridView.Size = new System.Drawing.Size(667, 220);
            this.pARCELAVENDADataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CODPARCELA";
            this.dataGridViewTextBoxColumn1.HeaderText = "CODPARCELA";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DATAVENCIMENTO";
            this.dataGridViewTextBoxColumn2.HeaderText = "DATAVENCIMENTO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "VALORPARCELA";
            this.dataGridViewTextBoxColumn3.HeaderText = "VALORPARCELA";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn4.HeaderText = "CODFUNCIONARIO_FK";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CODSITUACAO_FK";
            this.dataGridViewTextBoxColumn5.HeaderText = "CODSITUACAO_FK";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CODVENDA_FK";
            this.dataGridViewTextBoxColumn6.HeaderText = "CODVENDA_FK";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // cODPARCELALabel
            // 
            cODPARCELALabel.AutoSize = true;
            cODPARCELALabel.Location = new System.Drawing.Point(12, 41);
            cODPARCELALabel.Name = "cODPARCELALabel";
            cODPARCELALabel.Size = new System.Drawing.Size(82, 13);
            cODPARCELALabel.TabIndex = 2;
            cODPARCELALabel.Text = "CODPARCELA:";
            // 
            // cODPARCELATextBox
            // 
            this.cODPARCELATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pARCELAVENDABindingSource, "CODPARCELA", true));
            this.cODPARCELATextBox.Location = new System.Drawing.Point(141, 38);
            this.cODPARCELATextBox.Name = "cODPARCELATextBox";
            this.cODPARCELATextBox.Size = new System.Drawing.Size(200, 20);
            this.cODPARCELATextBox.TabIndex = 3;
            // 
            // dATAVENCIMENTOLabel
            // 
            dATAVENCIMENTOLabel.AutoSize = true;
            dATAVENCIMENTOLabel.Location = new System.Drawing.Point(12, 68);
            dATAVENCIMENTOLabel.Name = "dATAVENCIMENTOLabel";
            dATAVENCIMENTOLabel.Size = new System.Drawing.Size(110, 13);
            dATAVENCIMENTOLabel.TabIndex = 4;
            dATAVENCIMENTOLabel.Text = "DATAVENCIMENTO:";
            // 
            // dATAVENCIMENTODateTimePicker
            // 
            this.dATAVENCIMENTODateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.pARCELAVENDABindingSource, "DATAVENCIMENTO", true));
            this.dATAVENCIMENTODateTimePicker.Location = new System.Drawing.Point(141, 64);
            this.dATAVENCIMENTODateTimePicker.Name = "dATAVENCIMENTODateTimePicker";
            this.dATAVENCIMENTODateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dATAVENCIMENTODateTimePicker.TabIndex = 5;
            // 
            // vALORPARCELALabel
            // 
            vALORPARCELALabel.AutoSize = true;
            vALORPARCELALabel.Location = new System.Drawing.Point(12, 93);
            vALORPARCELALabel.Name = "vALORPARCELALabel";
            vALORPARCELALabel.Size = new System.Drawing.Size(95, 13);
            vALORPARCELALabel.TabIndex = 6;
            vALORPARCELALabel.Text = "VALORPARCELA:";
            // 
            // vALORPARCELATextBox
            // 
            this.vALORPARCELATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pARCELAVENDABindingSource, "VALORPARCELA", true));
            this.vALORPARCELATextBox.Location = new System.Drawing.Point(141, 90);
            this.vALORPARCELATextBox.Name = "vALORPARCELATextBox";
            this.vALORPARCELATextBox.Size = new System.Drawing.Size(200, 20);
            this.vALORPARCELATextBox.TabIndex = 7;
            // 
            // cODFUNCIONARIO_FKLabel
            // 
            cODFUNCIONARIO_FKLabel.AutoSize = true;
            cODFUNCIONARIO_FKLabel.Location = new System.Drawing.Point(12, 119);
            cODFUNCIONARIO_FKLabel.Name = "cODFUNCIONARIO_FKLabel";
            cODFUNCIONARIO_FKLabel.Size = new System.Drawing.Size(123, 13);
            cODFUNCIONARIO_FKLabel.TabIndex = 8;
            cODFUNCIONARIO_FKLabel.Text = "CODFUNCIONARIO FK:";
            // 
            // cODFUNCIONARIO_FKTextBox
            // 
            this.cODFUNCIONARIO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pARCELAVENDABindingSource, "CODFUNCIONARIO_FK", true));
            this.cODFUNCIONARIO_FKTextBox.Location = new System.Drawing.Point(141, 116);
            this.cODFUNCIONARIO_FKTextBox.Name = "cODFUNCIONARIO_FKTextBox";
            this.cODFUNCIONARIO_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODFUNCIONARIO_FKTextBox.TabIndex = 9;
            // 
            // cODSITUACAO_FKLabel
            // 
            cODSITUACAO_FKLabel.AutoSize = true;
            cODSITUACAO_FKLabel.Location = new System.Drawing.Point(12, 145);
            cODSITUACAO_FKLabel.Name = "cODSITUACAO_FKLabel";
            cODSITUACAO_FKLabel.Size = new System.Drawing.Size(103, 13);
            cODSITUACAO_FKLabel.TabIndex = 10;
            cODSITUACAO_FKLabel.Text = "CODSITUACAO FK:";
            // 
            // cODSITUACAO_FKTextBox
            // 
            this.cODSITUACAO_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pARCELAVENDABindingSource, "CODSITUACAO_FK", true));
            this.cODSITUACAO_FKTextBox.Location = new System.Drawing.Point(141, 142);
            this.cODSITUACAO_FKTextBox.Name = "cODSITUACAO_FKTextBox";
            this.cODSITUACAO_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODSITUACAO_FKTextBox.TabIndex = 11;
            // 
            // cODVENDA_FKLabel
            // 
            cODVENDA_FKLabel.AutoSize = true;
            cODVENDA_FKLabel.Location = new System.Drawing.Point(12, 171);
            cODVENDA_FKLabel.Name = "cODVENDA_FKLabel";
            cODVENDA_FKLabel.Size = new System.Drawing.Size(86, 13);
            cODVENDA_FKLabel.TabIndex = 12;
            cODVENDA_FKLabel.Text = "CODVENDA FK:";
            // 
            // cODVENDA_FKTextBox
            // 
            this.cODVENDA_FKTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pARCELAVENDABindingSource, "CODVENDA_FK", true));
            this.cODVENDA_FKTextBox.Location = new System.Drawing.Point(141, 168);
            this.cODVENDA_FKTextBox.Name = "cODVENDA_FKTextBox";
            this.cODVENDA_FKTextBox.Size = new System.Drawing.Size(200, 20);
            this.cODVENDA_FKTextBox.TabIndex = 13;
            // 
            // frmParcelaVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 423);
            this.Controls.Add(cODPARCELALabel);
            this.Controls.Add(this.cODPARCELATextBox);
            this.Controls.Add(dATAVENCIMENTOLabel);
            this.Controls.Add(this.dATAVENCIMENTODateTimePicker);
            this.Controls.Add(vALORPARCELALabel);
            this.Controls.Add(this.vALORPARCELATextBox);
            this.Controls.Add(cODFUNCIONARIO_FKLabel);
            this.Controls.Add(this.cODFUNCIONARIO_FKTextBox);
            this.Controls.Add(cODSITUACAO_FKLabel);
            this.Controls.Add(this.cODSITUACAO_FKTextBox);
            this.Controls.Add(cODVENDA_FKLabel);
            this.Controls.Add(this.cODVENDA_FKTextBox);
            this.Controls.Add(this.pARCELAVENDADataGridView);
            this.Controls.Add(this.pARCELAVENDABindingNavigator);
            this.Name = "frmParcelaVenda";
            this.Text = "frmParcelaVenda";
            this.Load += new System.EventHandler(this.frmParcelaVenda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fORM2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDABindingNavigator)).EndInit();
            this.pARCELAVENDABindingNavigator.ResumeLayout(false);
            this.pARCELAVENDABindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pARCELAVENDADataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FORM2DataSet fORM2DataSet;
        private System.Windows.Forms.BindingSource pARCELAVENDABindingSource;
        private FORM2DataSetTableAdapters.PARCELAVENDATableAdapter pARCELAVENDATableAdapter;
        private FORM2DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator pARCELAVENDABindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton pARCELAVENDABindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView pARCELAVENDADataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TextBox cODPARCELATextBox;
        private System.Windows.Forms.DateTimePicker dATAVENCIMENTODateTimePicker;
        private System.Windows.Forms.TextBox vALORPARCELATextBox;
        private System.Windows.Forms.TextBox cODFUNCIONARIO_FKTextBox;
        private System.Windows.Forms.TextBox cODSITUACAO_FKTextBox;
        private System.Windows.Forms.TextBox cODVENDA_FKTextBox;
    }
}